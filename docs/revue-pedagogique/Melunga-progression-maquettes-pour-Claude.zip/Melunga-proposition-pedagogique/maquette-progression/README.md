# Maquette locale du parcours Melunga

Aucun fichier de l’application ou du site modifié. Cette maquette indépendante montre une même proposition sur ordinateur et écran mobile ; elle ne constitue pas une APK.

Deux vues complémentaires : assemblage d’une phrase et petit échange. Les niveaux L1–L10 sont consultables pour examiner les objectifs, sans note de maîtrise ni déblocage de droits. Les fiches complètes de contenu restent à relire avec Claude et Kartech.

Les sept langues étudiées sont consultables : chinois, espagnol, anglais, italien, japonais, coréen pour francophones ; français pour sinophones. Les libellés d’interface de cette maquette sont en français pour la revue de Kartech ; ils ne remplacent pas les libellés localisés de l’application.

Les extraits L2–L10 proviennent de la réserve JSON locale au commit 49dca94 ; ils ne démontrent pas que les transitions proposées sont déjà préparées. L1 eau/thé et la question alternative sont des propositions de maquette ; la phonétique de thé est construite à partir des briques existantes et reste à relire. La scène se situe entre amis ; elle ne présente pas une formule de commande comme universellement polie.

L’audio de cette maquette utilise uniquement une voix du navigateur déjà disponible ; si aucune voix de la langue n’existe, un message le précise. Aucun appel vers les services Melunga et aucun suivi utilisateur. Aucun localStorage ou modification des données source.

Pour lancer : `python3 -m http.server 8912 --bind 127.0.0.1 --directory /workspace/melunga-reviews/maquette-progression` puis ouvrir localhost:8912. Paramètres de démonstration : `?lang=es&level=1&phase=1` ou `?lang=zh&level=1&phase=2`.

La cohérence des objectifs et de la progression doit être relue par Claude, les essais validés par Kartech, puis toute publication soumise à sa validation explicite.

Les questions reçues L1 et leurs aides phonétiques sont des propositions de démonstration à relire, pas de nouveaux contenus validés. La vue d’ensemble illustre les fonctions des rubriques ; elle ne reproduit pas leur catalogue complet. Les tâches des niveaux hauts sont des objectifs d’essai, sans moteur de correction automatique.

## Deuxième étape locale

- `echange.html` : échange par réplique dans les sept langues et les dix niveaux, avec rôles nommés, phrase entière, phonétique, sens et lecture complémentaire si fournie.
- `Écouter l’échange` montre les répliques ; `À moi de répondre` ne masque une réplique apprenant que si elle a déjà été affichée dans cette maquette.
- `Avec mes mots` propose une tâche orale avec un partenaire humain. Ce prototype ne simule pas un partenaire intelligent et n’attribue aucune note de maîtrise.
- L1 utilise un petit échange de démonstration eau/thé ou eau/café. Les nouveaux ponts L2 gardent la quantité et remplacent seulement la boisson ; ces propositions, leurs phonétiques et lectures restent à relire.
- Les variantes L3–L10 restent des extraits de la réserve : leur présence ne valide pas toutes les étapes de préparation.
- Le titre de la leçon suit sa situation réelle ; chaque leçon commence par la découverte.
- `presentation-niveaux.html` compare L1, L5 et L10 ; les trois fils détaillés repas/déplacements/rendez-vous se trouvent dans le document associé.

Contrôles v2 : 140 vues de dialogues (7 langues × 10 niveaux × 2 formats), 550 vérifications de masquage des tours apprenants, phrases complètes et première exposition contrôlées, navigation leçon→échange. Pas d’erreur JavaScript, pas de débordement horizontal, ni de défilement vertical constaté pour les répliques guidées sélectionnées à 390×844 et 1440×960. Les aides de lecture dépliées et d’autres tailles peuvent demander du défilement. Aucun essai natif APK ni service audio distant contrôlé.

`verification.json` concerne la première maquette. `verification-v2.json` concerne cette seconde étape.
