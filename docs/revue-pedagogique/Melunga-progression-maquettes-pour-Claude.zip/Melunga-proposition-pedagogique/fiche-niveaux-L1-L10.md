# Melunga — dix fiches de progression à essayer

Proposition documentaire locale du 20 octobre 2026, préparée pour Kartech et Claude. Aucun contenu applicatif modifié, aucune publication. Les niveaux constituent un chemin vers l’autonomie dans la conversation quotidienne ; terminer une liste ne démontre pas la maîtrise.

Sources : `progression-L1-L10-vers-maitrise.md` et l’extraction des 841 modèles `modeles-progression-source.json`. Les références ci-dessous identifient des contenus existants à conserver. Une phrase indiquée **« pont proposé »** n’est pas présentée comme un contenu déjà livré ou validé : Claude doit en vérifier le naturel, la phonétique et l’audio avant essai. Les exemples français illustrent le sens, pas une grammaire à imposer aux sept langues.

**Règle des trois supports :** même objectif, mêmes acquis et mêmes aides sur ordinateur, site mobile et application ; gestes et disposition adaptés. Audio, phonétique pour le lecteur et traduction restent accessibles. Lors des essais, observer séparément réponse avec modèle, réponse avec aide et réponse spontanée. Aucun quota rigide ni verrouillage automatique n’est proposé.

## L1 — Je peux obtenir quelque chose de simple

**Objectif :** comprendre un choix très court, demander ce qu’on veut et remercier.

**Acquis exacts au départ :** aucun prérequis dans la langue étudiée. Faire découvrir eau puis thé en contexte, ainsi que bonjour/merci ; ces derniers sont des blocs, pas un cours de conjugaison. Ne pas exiger lecture autonome du chinois.

**Nouveauté principale :** une demande stable avec un élément remplaçable. Une autre formulation de politesse est une découverte distincte, pas une variante supplémentaire obligatoire le même jour.

**Séquence A — reconnaître, puis choisir :** entendre et comprendre `我要水。` (« je veux de l’eau »), puis réutiliser la phrase dans une scène différente. **Pont proposé :** `我要茶。` ; introduire 茶 avant de le substituer. En espagnol, découvrir `Un café, por favor.` puis `Un té, por favor.` ; changer uniquement la boisson déjà entendue.

**Séquence B — participer à un choix :** après écoute complète de l’échange, répondre à « eau ou thé ? » par la boisson choisie ou la demande connue. Les questions chinoise `水还是茶？` et espagnole `¿Agua o té?` sont des **ponts proposés** à préparer comme oral reçu, avant de masquer une réponse. Répéter ensuite l’échange avec un choix personnel différent.

**Réserve conservée :** besoin, identité, lieu et prix seront de petites séquences ultérieures du L1, pas des exigences simultanées dès l’entrée. Préparer aussi un bloc de demande de répétition.

**Tâche personnelle :** choisir sa boisson et l’obtenir dans un mini-échange dont le choix n’est pas prérempli.

**Repère pour poursuivre :** l’apprenant comprend l’intention du choix et change correctement la boisson sans se limiter à recopier le modèle. Si l’audio ou la phonétique aide, le noter ; si le sens reste incertain, refaire une scène plus simple.

**Références existantes :** `L1-fr-es-09`, `L1-fr-zh-03`, `L1-fr-zh-09`.

## L2 — Je précise ma demande

**Objectif :** enrichir une phrase connue d’une quantité, puis d’un repère de lieu ou de moment dans une autre séquence.

**Acquis exacts :** demande d’une boisson, eau/thé/café préparés à l’écoute, remerciement et compréhension d’un choix simple. Les nombres un/deux et l’unité utile sont découverts avant leur emploi.

**Nouveauté principale :** quantité + nom familier ; garder la forme de demande aussi stable que possible. Les compteurs chinois sont appris avec leur objet, pas comme une série de règles à mémoriser.

**Séquence A — un puis deux :** en chinois, faire découvrir `一杯咖啡` puis `两杯咖啡` comme groupes audibles avant une demande complète. La réserve contient `我想要两杯咖啡。` ; introduire `想要` séparément si le chemin L1 utilisait seulement `我要`. **Ponts proposés :** `我要一杯茶。` → `我要两杯茶。` pour éviter de changer verbe et quantité à la fois. En espagnol, la réserve `Quisiera dos cafés, por favor.` reste utile ; **pont proposé** `Un café, por favor.` → `Dos cafés, por favor.` avant la nouvelle forme `Quisiera`.

**Séquence B — préciser sans cumuler :** réemployer une demande avec une autre quantité ; ensuite seulement découvrir une demande de billets. En chinois, `我要两张票。` introduit 张 et 票 dans une séquence propre, après l’unité 杯, sans les présenter comme interchangeables. Les horaires et lieux suivront avec les mêmes principes, après découverte de leurs mots.

**Tâche personnelle :** commander la quantité correspondant à ses compagnons, puis comprendre la confirmation reçue.

**Repère pour poursuivre :** le choix de quantité est intentionnel, la demande reste compréhensible et la confirmation de l’autre est reconnue. Une erreur de compteur appelle une reprise ciblée, pas le redémarrage de tout L1.

**Références existantes :** `L2-fr-es-01`, `L2-fr-zh-01`, `L2-fr-zh-02`.

## L3 — Je pose une question et je réponds

**Objectif :** faire circuler l’échange sur un contenu familier, sans introduire en même temps un nouveau domaine.

**Acquis exacts :** quelques demandes et besoins L1, quantités/choix L2, merci/refus poli ; pour chaque séquence, le nom et le verbe utilisés ont déjà été compris. Les questions simples ont déjà été rencontrées comme blocs reçus ; ici on en développe la construction.

**Nouveauté principale :** transformer une intention connue en question ; personne puis mécanisme interrogatif sont préparés successivement si la langue l’exige.

**Séquence A — demander un choix :** en espagnol, `¿Qué quieres?` réemploie le sens de « vouloir », mais `quiero`→`quieres` doit être découvert. On répond avec une demande L1 familière. En chinois, `你喝什么？` demande ce que l’autre boit ; préparer 喝 comme action avant la question. Cette phrase ne doit pas être présentée comme l’équivalent mécanique de `¿Qué quieres?`.

**Séquence B — fermer puis relancer :** `你是学生吗？` réutilise l’identité travaillée dans une séquence L1 ; apprendre ensuite les réponses correspondantes 是/不是 et distinguer celles-ci d’un oui/non universel. Pour garder le thème boire, **pont proposé** : `你要茶吗？` avec réponses adaptées au verbe. En espagnol, **pont proposé** : `¿Quieres té?` puis `Sí, gracias / No, gracias`, déjà entendus en contexte. La relance « et toi ? » vient après un premier échange compris.

**Tâche personnelle :** demander ce que l’autre souhaite, choisir sa propre réponse puis poser une question de retour.

**Repère pour poursuivre :** l’apprenant distingue question et réponse, comprend une réponse différente de la sienne et adapte un élément connu. Les mêmes répliques peuvent être rejouées avec aide avant un essai moins guidé.

**Références existantes :** `L3-fr-es-03`, `L3-fr-zh-02`, `L3-fr-zh-09`.

## L4 — Je parle de ma vraie journée

**Objectif :** combiner action, moment et lieu pour parler de soi, puis répondre à l’autre.

**Acquis exacts :** demandes et déplacements simples L1, compléments L2, question/réponse L3. Préparer boire, manger, travailler ou regarder selon les actions effectivement choisies ; ne pas supposer que tout le vocabulaire quotidien est déjà connu.

**Nouveauté principale :** enrichir une action connue par un repère habituel. Famille, logement et métier restent des séquences complémentaires, pas une seule biographie à apprendre.

**Séquence A — action puis moment :** découvrir `早上我喝一杯咖啡。` à partir du groupe boisson/quantité connu ; travailler 早上 séparément avant de le combiner. En espagnol, `Normalmente como en casa.` permet de partir d’une action + lieu, puis d’ajouter l’habitude. Si `como en casa` n’a pas encore été découvert, le préparer comme **pont proposé** avant `Normalmente`.

**Séquence B — une autre partie de la journée :** `晚上我做饭。` ou `晚上我看电视。` servent à parler du soir ; introduire chaque action séparément. L’apprenant rapproche matin et soir dans deux phrases, puis répond à une question reçue préparée. Le changement de personne « je/mon conjoint » n’est ajouté qu’ensuite.

**Tâche personnelle :** donner deux informations vraies sur sa journée et répondre à une demande de précision sur le moment ou le lieu.

**Repère pour poursuivre :** la description ne recopie pas la journée du personnage ; l’apprenant peut changer un moment ou une activité et rester compris. La précision des choix compte davantage que la longueur.

**Références existantes :** `L4-fr-es-01`, `L4-fr-zh-02`, `L4-fr-zh-03`.

## L5 — Je raconte un événement

**Objectif :** raconter quelque chose qui s’est passé, puis enchaîner deux actions familières.

**Acquis exacts :** actions et lieux du quotidien L4, questions simples L3, moments L2. Choisir d’abord un seul verbe connu : travailler, regarder un film ou rentrer, selon ce qui a été enseigné.

**Nouveauté principale :** situer l’action passée selon la langue, sans changer simultanément tous les verbes et personnes.

**Séquence A — aujourd’hui/hier :** `Ayer trabajé mucho.` demande une forme verbale différente de `trabajo` ; introduire le repère puis la forme, en plusieurs écoutes si nécessaire. En chinois, `昨天我工作了。` est travaillé sur ce cas précis ; 了 n’est pas enseigné comme un auxiliaire universel du passé. Préparer hier puis la phrase entière avec son contexte.

**Séquence B — après :** `后来我回家了。` permet d’enchaîner avec une action déjà connue. L’apprenant raconte deux moments avec des mots disponibles ; les connecteurs sont d’abord reçus et compris. L’alternance négative « je ne l’ai pas fait » vient dans une séquence distincte, pas en même temps que le premier récit.

**Tâche personnelle :** dire un événement réel d’hier, ajouter ce qui s’est passé après et répondre à une question simple.

**Repère pour poursuivre :** l’autre comprend le moment et l’ordre des actions ; l’apprenant peut remplacer l’événement sans perdre la structure. Il peut demander de répéter au lieu de devoir comprendre toutes les relances nouvelles.

**Références existantes :** `L5-fr-es-01`, `L5-fr-zh-01`, `L5-fr-zh-07`.

## L6 — Je construis un projet avec quelqu’un

**Objectif :** proposer une activité, comprendre une indisponibilité et convenir d’un autre moment.

**Acquis exacts :** activité et lieu déjà connus, jours/heures rencontrés en L2, question/réponse L3, récit et repères temporels consolidés. Le futur est exprimé naturellement dans chaque langue ; ne pas imposer une traduction du futur français.

**Nouveauté principale :** ajuster le projet à la réponse de l’autre. Les synonymes d’intention/invitation sont des enrichissements ultérieurs.

**Séquence A — proposer et confirmer :** `Quedamos el sábado a las diez.` reprend jour et heure ; un premier dialogue situe la proposition avec une activité connue. La réserve contient aussi une variante de lieu `Quedamos delante de la estación.` ; ne pas ajouter lieu nouveau et horaire nouveau au même premier passage.

**Séquence B — refuser avec alternative :** `No puedo, pero mañana sí.` ou `我不行，不过星期天可以。` sont entendus, compris et réutilisés. Le lien « mais » sert à garder l’échange ouvert. Si ces éléments sont nouveaux, apprendre d’abord le refus comme bloc, puis la proposition d’un autre jour. L’apprenant déplace le projet vers un moment personnel ; il ne récite pas nécessairement dimanche.

**Tâche personnelle :** organiser une sortie alors que l’autre refuse le premier horaire.

**Repère pour poursuivre :** parvenir à un accord compris par les deux, ou constater clairement qu’aucun moment ne convient. Pouvoir confirmer ce qui a changé compte davantage que connaître plusieurs formulations de futur.

**Références existantes :** `L6-fr-es-04`, `L6-fr-es-05`, `L6-fr-zh-05`.

## L7 — J’explique pourquoi je choisis

**Objectif :** comparer des possibilités, exprimer une préférence et la justifier.

**Acquis exacts :** deux objets/lieux familiers, mots descriptifs déjà compris, choix et préférence rencontrés dans les niveaux précédents. Préparer séparément « moins cher », « pratique » et les moyens de transport s’ils sont nécessaires.

**Nouveauté principale :** relier deux idées connues. Comparaison et cause sont d’abord deux séquences, puis une tâche commune.

**Séquence A — comparer :** `这个比那个更便宜。` met en rapport deux objets visibles connus. Garder l’adjectif constant puis inverser les objets ; éviter d’ajouter plusieurs comparatifs irréguliers dans ce premier passage. Dans une autre langue, la transformation comparative suit ses règles propres.

**Séquence B — choisir et justifier :** `Prefiero el mercado porque es más barato.` et `我更喜欢坐地铁，因为更方便。` donnent deux supports. Les deux propositions sont d’abord comprises séparément. L’apprenant fait ensuite son choix avec une raison déjà disponible, puis entend une préférence opposée sans être obligé de changer d’avis.

**Tâche personnelle :** choisir entre deux trajets, lieux ou objets et répondre à « pourquoi ? » avec une raison personnelle simple.

**Repère pour poursuivre :** préférence et raison correspondent, l’apprenant comprend que l’autre peut choisir autrement et peut reformuler son propre choix. La longueur de la justification n’est pas imposée.

**Références existantes :** `L7-fr-es-04`, `L7-fr-zh-03`, `L7-fr-zh-05`.

## L8 — J’adapte une demande et je trouve un accord

**Objectif :** obtenir un changement possible, comprendre une limite et proposer une condition concrète.

**Acquis exacts :** besoin/demande polie simple dès L1, projet/alternative L6, raison et comparaison L7. Conserver au départ le même objet et la même situation ; les règles de politesse élaborées sont propres à la langue et au rôle.

**Nouveauté principale :** lier condition et conséquence ; nuancer la demande dans une autre séquence avant de les combiner.

**Séquence A — demander une adaptation :** `¿Podría cambiar la fecha?` réutilise une intention de changement préparée. Comparer l’effet de la formule à une demande déjà connue, sans ajouter immédiatement de nouveaux pronoms ou un lexique administratif. **Pont proposé** si nécessaire : demande simple de changement de rendez-vous avec les dates déjà apprises.

**Séquence B — poser une condition :** `如果便宜一点，我就买。` relie prix et achat connus ; découvrir d’abord l’offre du vendeur pour comprendre le lien. Puis écouter une limite telle que `Vale, pero solo si el precio no cambia.` et reformuler l’accord. Il ne s’agit pas de traductions mot à mot ; chaque dialogue garde une situation cohérente.

**Tâche personnelle :** demander un autre moment ou une autre option et accepter/refuser une condition selon son besoin.

**Repère pour poursuivre :** l’apprenant sait dire à quelle condition il accepte et comprend ce que l’autre accepte réellement. Un accord mal compris doit pouvoir être clarifié avec les aides disponibles.

**Références existantes :** `L8-fr-es-02`, `L8-fr-es-06`, `L8-fr-zh-03`.

## L9 — Je répare un malentendu et je cherche une solution

**Objectif :** traiter un imprévu à plusieurs étapes, vérifier ce qu’on a compris puis choisir une alternative.

**Acquis exacts :** blocs de secours des premiers niveaux, repères de temps/lieu, récit L5, projet alternatif L6, raisons L7 et demandes adaptées L8. Le scénario commence dans un contexte familier pour que la difficulté vienne de l’échange.

**Nouveauté principale :** reformuler une information reçue et faire confirmer. L’incertitude et le lexique d’incident sont préparés avant d’enrichir la scène.

**Séquence A — constater et demander :** `有个问题：航班取消了。怎么办？` fournit le problème et la recherche d’une solution. Si l’annulation du vol est un lexique nouveau, commencer avec un rendez-vous familier modifié, comme **pont proposé**, puis transférer au transport après découverte du vocabulaire.

**Séquence B — vérifier :** `Si he entendido bien, el tren sale a las nueve, ¿no?` et `如果我没理解错，下一班车是十点？` servent à contrôler une information reçue. L’interlocuteur peut confirmer ou corriger l’heure ; préparer les deux réponses. Ensuite seulement l’apprenant choisit un autre départ et confirme sa décision.

**Tâche personnelle :** résoudre un changement d’horaire ou un transport annulé dont l’alternative diffère du dialogue modèle.

**Repère pour poursuivre :** repérer l’écart, obtenir une précision et choisir une solution comprise. Demander une répétition appropriée fait partie de l’autonomie ; deviner l’heure sans vérifier n’en est pas une preuve.

**Références existantes :** `L9-fr-es-09`, `L9-fr-zh-07`, `L9-fr-zh-08`.

## L10 — Je choisis mes phrases pour converser

**Objectif :** tenir une conversation quotidienne en combinant le répertoire acquis, avec relances, objections et réparations.

**Acquis exacts :** besoins/questions, description personnelle, passé, projet, raison/comparaison, condition et clarification des niveaux précédents ; tous ne sont pas employés obligatoirement dans chaque échange. L’apprenant sait demander l’aide dont il a besoin.

**Nouveauté principale :** choisir la ressource selon l’intention et la réaction de l’autre, plutôt que suivre un ordre de phrases imposé. Quelques tournures de liaison enrichissent le répertoire sans devenir un concours de mots rares.

**Séquence A — avis et objection :** `Es verdad, pero no es tan sencillo.` permet de reconnaître une objection et de continuer. L’apprenant décide s’il maintient son choix, l’adapte ou demande une précision. Le contenu de sa réponse vient de son besoin ; plusieurs réponses cohérentes sont acceptables.

**Séquence B — vérifier et conclure :** `如果我理解得对，你觉得这个方案更好？` sert à reformuler le choix de l’autre, puis `总的来说，我们都同意。` peut résumer un accord réel. Si les deux ne sont pas d’accord, ne pas imposer cette conclusion : **pont proposé**, à rédiger et valider, pour résumer un désaccord ou reporter la décision.

**Tâche personnelle :** organiser un repas, une sortie ou un déplacement avec plusieurs contraintes familières. L’interlocuteur modifie une contrainte et pose une relance non annoncée ; l’apprenant répond avec ses ressources, explique un choix puis confirme l’accord ou le désaccord.

**Repère de consolidation :** l’échange reste compréhensible, les réponses tiennent compte de l’autre et l’apprenant peut réparer un malentendu sans repartir du dialogue écrit. Observer ce résultat dans des scènes variées et lors d’une reprise ultérieure ; ne pas appeler « maîtrise » le seul achèvement des dix niveaux. Audio et phonétique restent disponibles pour préparer et réviser.

**Références existantes :** `L10-fr-es-02`, `L10-fr-zh-03`, `L10-fr-zh-04`.

## Ponts à faire proposer par Claude avant intégration

- L1 : oral reçu très court et nouvelle boisson introduite avant substitution ; premier dialogue entièrement découvert avant rappel masqué.
- L2 : quantité sur demande inchangée ; séparation d’une nouvelle formule polie et d’un nouveau compteur.
- L3 : questions sur mots et actions déjà rencontrés ; réponses adaptées à chaque mécanisme interrogatif.
- L4 : action + lieu préparés avant ajout de fréquence, puis biographies personnalisables.
- L5 : paires action connue/événement passé et premier enchaînement ; les formes négatives et les personnes nouvelles arrivent ensuite.
- L6 : proposition→refus→alternative→confirmation avec plusieurs horaires plausibles.
- L7 : deux propositions déjà connues avant leur liaison ; comparaison et cause séparées au premier passage.
- L8 : demande simple→demande adaptée ; condition sur un vocabulaire familier.
- L9 : première reformulation avec confirmation et correction possibles, puis incident plus riche.
- L10 : tâches à plusieurs issues, y compris accord partiel, désaccord et décision reportée.

Ces ponts peuvent réutiliser des cartes existantes après contrôle : la liste ne signifie pas que toutes leurs phrases sont absentes du site. Le manque identifié est leur préparation explicite dans la séquence proposée. Les modèles spécialisés restent en enrichissement. Les autres langues doivent garder les mêmes capacités de sortie tout en décomposant leurs difficultés propres.
