# Melunga — dossier de proposition à relire avec Claude

20 octobre 2026. Documents et maquettes créés uniquement dans `/workspace/melunga-reviews`, hors du dépôt applicatif. Source de contenu examinée : `feat/conversation-integration` à `49dca94`. Aucun changement publié, aucun commit ni push de cette proposition.

## Décisions de Kartech à respecter

- Garder le contenu existant et l’améliorer.
- Apprentissage par assemblage progressif de mots, blocs et structures ; chaque niveau prépare les suivants.
- L1–L10 forment un parcours cohérent vers la maîtrise fonctionnelle de la conversation quotidienne.
- Inclure les sept langues étudiées, les rubriques et leurs contenus, sur ordinateur, site mobile et application Android.
- La phonétique adaptée au lecteur reste une aide centrale et disponible.
- Claude relit les propositions et la réalisation avant publication ; toute mise en ligne nécessite la validation explicite de Kartech.

## Ordre de lecture

1. `progression-L1-L10-vers-maitrise.md` : capacités de sortie, fil rouge et critère L10.
2. `bilan-progression-difficulte.md` : constats et exemples de sauts de difficulté.
3. `fiche-niveaux-L1-L10.md` : dix fiches concrètes et références aux contenus existants.
4. `declinaison-sept-langues.md` : transitions adaptées aux sept couples actuellement livrés.
5. `rubriques-et-parcours-proposition.md` : place des rubriques, inventaire et cohérence des trois supports.
6. `maquette-progression/overview.html` puis `index.html` : vues de proposition, à examiner comme scénarios et non comme contenus déjà validés.

Les rapports spécialisés audit-catalogue-detail, audit-conversation-detail et audit-parcours-detail fournissent les preuves. Le rapport phonétique détaillé est secondaire : la priorité actuelle reste la progression et la difficulté.

## Maquettes disponibles

- Vue d’ensemble des dix niveaux et des rubriques de consolidation.
- Séance : découvrir une phrase, remplacer un élément, réutiliser dans un échange.
- Même séance adaptée à l’ordinateur et au mobile ; pas de prétention à un test natif APK.
- Sept langues sélectionnables, avec extraits des dix niveaux ; les objectifs et les transitions restent proposés. La présence d’un extrait n’est pas une validation de toute sa séquence.
- Les textes d’interface du prototype sont en français pour la revue. Les couples conversation actuels sont fr→en/es/it/zh/ja/ko et zh→fr. L’élargissement à toutes les autres langues maternelles est un chantier distinct.
- L1 eau/thé et questions reçues incluent des ponts de démonstration à relire. Les questions et leurs phonétiques ne sont pas certifiées natives.

## Contrôles du prototype

Dans Chromium local, 210 états rendus : sept langues × dix niveaux × trois phases. Aucune erreur JavaScript, aucun dépassement horizontal constaté ; découvertes et assemblages vérifiés à 390×844. Remplacement d’un mot, révélation d’une réponse et navigation vers L10 vérifiés. Captures ordinateur à 1440×960 et mobile à 390×844. Cela ne vérifie ni les services audio réels, ni une APK, ni les interfaces de production.

L’audio du prototype se limite à une voix locale du navigateur si disponible. Les réglages et droits d’accès de Melunga ne sont pas utilisés ; aucun suivi de maîtrise ou synchronisation n’est enregistré.

## Ce que Claude doit relire

- cohérence des dix niveaux et des prérequis, en gardant L10 comme cible de conversation autonome ;
- fidélité à la méthode : une nouveauté principale préparée, réemploi actif, compréhension de l’autre ;
- familles à séparer et exemples plus avancés à conserver en enrichissement ;
- transitions propres à chaque langue et phrases complètes correctes ;
- phonétiques des nouveaux ponts, naturel des questions et registre de l’échange ;
- rôle des rubriques pour éviter plusieurs parcours indépendants ou des numérotations contradictoires ;
- différence entre reconnaissance, mémorisation d’une phrase et capacité à créer/répondre ;
- absence de promesse de maîtrise garantie ou de pourcentage de couverture non mesuré.

## Message à transmettre

> Codex a préparé localement une proposition complète de progression L1–L10, sa déclinaison pour les sept langues et une répartition des rubriques. Le contenu existant est conservé comme réserve ; les changements portent d’abord sur l’ordre, les prérequis, les ponts et les occasions de créer une nouvelle phrase. Deux maquettes complémentaires montrent le parcours global et la séance découvrir→assembler→échanger, en ordinateur et mobile. Merci de relire la cohérence pédagogique, la cible de maîtrise quotidienne au L10, les transitions et les ponts linguistiques avant réalisation. Les interfaces du prototype et ses extraits restent des propositions. Ne rien fusionner, déployer ou publier sans validation explicite de Kartech.

## Règle précisée par Kartech : les leçons sont faites de phrases

La phrase utile en contexte est l’unité principale de chaque leçon, dès L1. Elle est affichée, traduite, accompagnée de la phonétique adaptée au lecteur et prononçable en entier. Les mots et morceaux remplaçables sont découverts dans une phrase ; une liste de mots ou de règles ne remplace pas la leçon. Les rubriques de vocabulaire servent à retrouver des briques avec leurs phrases d’emploi.

Exemple de chaîne illustrative : « Je veux de l’eau. » → « Je veux du thé. » → « Je veux boire. » → « Je veux boire du thé. » → « Tu veux boire du thé ? ». Chaque changement de construction est préparé dans une séquence distincte. La phrase complète correcte fait autorité, avec les adaptations propres à chaque langue.

Cette règle concerne les leçons classiques autant que Mes phrases, les révisions, les thèmes et les dialogues, sur les trois supports. Les expressions courtes naturelles (« Bonjour », « Merci ») restent possibles comme répliques en situation, sans imposer artificiellement un sujet et un verbe à chaque échange.

## Complément : fils quotidiens et échanges

Lire `trois-fils-quotidiens-L1-L10.md` : 30 étapes illustratives réparties entre repas, déplacements et rendez-vous. Les références citées existent ; les phrases de transition restent des propositions.

La maquette `echange.html` ajoute des échanges réels extraits de la réserve, des rôles, des aides et une première exposition avant masquage. L’exercice « Avec mes mots » se fait avec un partenaire humain : il ne constitue pas une conversation automatique ou une validation de maîtrise. La progression finale et les ponts nouveaux doivent être relus, en particulier les variantes L2 qui évitent de changer simultanément formulation, quantité et boisson. Les extraits plus avancés restent à séquencer.

La capture `presentation-niveaux.png` montre L1 (remplacer), L5 (raconter) et L10 (répondre selon son intention). Les contrôles du prototype sont consignés dans `verification-v2.json` ; ils ne prouvent pas l’efficacité pédagogique et ne remplacent pas les essais sur appareil.
