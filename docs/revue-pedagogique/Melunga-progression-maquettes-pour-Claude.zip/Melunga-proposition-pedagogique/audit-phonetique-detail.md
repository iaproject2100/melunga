# Revue locale de la phonétique Melunga

20 octobre 2026 — dépôt local `49dca94`. Aucune donnée ni aucun écran modifié. Aucun appel réseau ou audit audio natif. Cette revue vérifie les mécanismes, la couverture des champs et des exemples ciblés dans les sept langues, pas chaque prononciation des 32 115 cartes.

## Compréhension de la méthode

La phonétique est une aide de prononciation conçue pour les habitudes de lecture de la langue maternelle. Elle permet de parler sans apprendre d’abord une transcription savante, puis de réemployer les mots et structures. Elle doit rester disponible selon le besoin. La phrase écrite originale, l’aide adaptée, le sens et l’audio ont des rôles complémentaires. Une romanisation standard n’est pas automatiquement une adaptation francophone, japonaise ou coréenne.

## Fonctionnement constaté

`app.html:3196`, fonction `phonOf` :

- Chinois étudié : `phf` pour francophones, `phs` hispanophones, `phe` anglophones, `phi` italophones ; pinyin `py` en repli. Le bouton pinyin force `py`, mais la phonétique maternelle est le mode initial (`app.html:3185`).
- Autres langues étudiées : `pf` pour francophones, `ps` hispanophones, `py` anglophones, `pi` italophones ; `phon` en caractères chinois pour les sinophones.
- Lecteurs japonais/coréens : `pj` / `pk` sont prévus dans le code mais absents de toutes les cartes ; la fonction affiche donc `py`, ou rien si celui-ci est vide.
- Conversation : sept couples actuellement livrés, fr→en/es/it/zh/ja/ko et zh→fr. Chaque phrase a `phon`; zh/ja/ko ont aussi `reading`. Le panneau distingue lecture et phonétique (`construire.js:378`, `:405`), expose la convention et appelle l’audio sur la vraie phrase, pas sur son approximation (`:380`, `:406`).

## Points à traiter

| Priorité | Observation vérifiable | Conséquence et proposition |
|---|---|---|
| Haute | Aucun `pj` ni `pk` dans les 32 115 cartes, alors que le sélecteur offre ces replis dans `phonOf`. | L’expérience de ces lecteurs ne réalise pas encore la promesse d’une phonétique propre à leur langue maternelle. Prévoir une production dédiée ou identifier clairement l’aide comme romanisation non adaptée. Ne pas annoncer une couverture phonétique de tous les couples. |
| Haute | `py` vide sur 217 cartes françaises et 659 anglaises. Exemples : `J’ai bien assaisonné.` (L2), `It's for her.` (L2). | Un anglophone apprenant le français peut avoir une aide vide ; lecteurs ja/ko rencontrent aussi des blancs lorsqu’ils dépendent du repli. Produire les aides manquantes et tester les couples réellement proposés. Les champs propres à la langue étudiée elle-même ne sont pas comptés comme traductions manquantes. |
| Haute | Cartes espagnoles `jefe` : `Se convirtió en jefe.` (L3), `Te presento a mi jefe.` (L4), etc., donnent `RÉ-fé`; `¿Manejan devoluciones internacionales?` (L10) donne `ma-NÉ-ran`. La convention conversation prescrit `j/ge/gi→KH`. | Deux codes pour le même son entre leçons et conversation. Normaliser après décision éditoriale et écoute, en commençant par le lexique récurrent. Ne pas remplacer mécaniquement chaque r du corpus. |
| Haute | `我不懂` : carte classique L2 `ouo bou dong`; conversation `L1-fr-zh-11` `ouo pou tong`. `我要一杯咖啡` : carte `ouo yao i beï ka-feï`; conversation `L1-fr-zh-03` `ouo yao i peï ka-feï`. | b/p et d/t risquent d’être interprétés comme de nouvelles prononciations par un débutant. Ce sont des stratégies possibles d’approximation d’oppositions non identiques au français ; choisir une convention et l’expliquer avec audio, plutôt que déclarer sans écoute l’une entièrement vraie et l’autre fausse. |
| Moyenne | `我是学生` : carte `ouo chr chu-eu cheung`; conversation `L1-fr-zh-01` `ouo chr süé-cheng`. | La même phrase change sensiblement de découpage et de lettres ; `ü` n’est pas explicité dans la convention actuelle. Définir comment le lecteur français doit produire la voyelle, puis harmoniser les deux catalogues. |
| Haute | Chinois : les approximations maternelles ne portent pas les tons. C’est explicitement assumé dans `L1-fr-zh.json`. Le pinyin et l’audio sont présents séparément. | Conserver l’aide maternelle, mais la première découverte doit relier l’écoute aux tons sans exiger d’emblée la lecture des caractères. L’absence de tons dans l’approximation n’est pas un champ manquant ; l’aide seule ne suffit cependant pas à distinguer tous les mots. Tester une aide très légère, avant toute UI nouvelle. |
| Moyenne | `元気ですか` : carte `guén-ki-dé-sou-ka`; conversation `L5-fr-ja-04` `gén-ki dé-sou ka`. | Pour un lecteur français, `gé` peut déclencher /ʒ/ plutôt que /g/. Préférer une convention non ambiguë telle que celle déjà employée dans les cartes, après contrôle audio. Autre dérive de convention : `wa` vs `oua` pour la particule は ; choisir un code cohérent. |
| Moyenne | `駅はどこですか` : carte `é-ki-oua do-ko-dé-sou-ka`, conversation `L1-fr-ja-05` `é-ki wa do-ko dé-sou ka`. `もっと安いのはありますか` : `mo-tto` vs `mot-to`. | Certaines différences sont de segmentation, pas d’erreur de son. Il faut néanmoins un code stable pour les voyelles longues et consonnes doubles : la durée peut changer le mot. Le découpage en blocs doit aider l’assemblage sans effacer ces durées. L’accent mélodique japonais n’est pas rendu par ces approximations ; ne pas le confondre avec l’accent tonique espagnol. |
| Haute | Coréen : convention L1 parle de `eo=ㅓ`, `eu=ㅡ`, mais la carte `저는 학생이에요` donne `djo-neun...`, la conversation `L1-fr-ko-01` `djeo-neun...`; `더워요` donne `do-ouo-yo` vs `deo-oueo-yo`. | Un francophone ne sait pas spontanément comment lire eo/eu dans cette convention mixte. Définir un code adapté, accompagné d’exemples audio courts, et l’appliquer sans multiplier des translittérations concurrentes. |
| Haute | `목말라요` : carte `mok-mal-la-yo`, conversation `L1-fr-ko-07` `mong-mal-la-yo`. `음악을 좋아해요` : carte `eum-ak-eul...`, conversation `L1-fr-ko-08` `eum-ag-eul...`. | Le coréen demande de contrôler la prononciation en chaîne (assimilations et enchaînements), pas uniquement de translittérer le hangeul. Les deux exemples ne relèvent pas du même mécanisme ; demander une relecture native avant arbitrage. Une différence peut être une correction de prononciation réelle plutôt qu’une simple incohérence typographique. |
| Moyenne | Anglais : `I'm a student` carte `STOU-deunt`, conversation `L1-fr-en-01` `STYOU-deunt`; `I'm hot` carte `HAT`, conversation `HOT`. | Plusieurs variantes dialectales peuvent être légitimes, mais l’apprenant a besoin d’une variété annoncée et cohérente avec l’audio (la convention conversation annonce le britannique). Comparer au moteur audio effectivement utilisé ; ne pas imposer l’identité de toutes les réalisations naturelles. |
| Moyenne | Français pour sinophones : `Je suis étudiant` carte `茹斯威艾图迪翁`, conversation `L1-zh-fr-01` `热 绥 埃居迪昂`; `J’ai faim` carte `热凡`, conversation `L1-zh-fr-07` `热 方`. | Les caractères choisis transportent leurs propres sons/tons et ne notent pas exactement les voyelles françaises. Adopter une convention stable et montrer que le français n’a pas les tons du mandarin. La convention conversation explique déjà le rythme de groupe : bon point à conserver. |

## Décomptes de comparaison, à interpréter correctement

Après rapprochement de phrases en ignorant ponctuation/espaces, des différences entre la phonétique des variantes conversation et celle des cartes existent sur 35 occurrences anglaises, 25 espagnoles, 37 italiennes, 29 chinoises, 8 japonaises, 36 coréennes et 56 françaises pour sinophones. Ce ne sont PAS des taux d’erreurs : certaines différences sont volontaires, dialectales, typographiques ou des améliorations. Le rapprochement choisit une seule carte lorsqu’un même texte est dupliqué ; c’est un repérage éditorial, pas un diagnostic automatique définitif.

Italien : les cartes emploient rarement les MAJUSCULES d’accentuation, alors que les conversations les annoncent et les utilisent (`Sono studente` : `so-no stou-dènn-té` contre `SO-no stou-DÈN-té`). Harmoniser la fonction des capitales et des accents écrits. Pour toutes les langues, ne pas promettre que « majuscules = accent tonique lexical » couvre également le français, le japonais, le chinois et le coréen.

## Améliorations conservant le contenu

1. Rédiger une petite fiche de convention par couple effectivement servi : sons, accents, durées, limites. Distinguer phonétique adaptée et lecture standard.
2. Faire relire d’abord les mots/blocs récurrents L1–L3 avec un échantillon audio, puis propager une convention décidée aux variantes. Garder un lexique de référence pour éviter que café, étudiant, eau, vouloir changent de code selon l’écran.
3. Contrôler la phrase complète après assemblage : élisions, liaisons, assimilations et rythme peuvent dépendre des mots voisins. Le son ne s’assemble pas toujours par simple collage des transcriptions des briques.
4. Tester l’aide auprès d’un lecteur de la langue maternelle concernée : peut-il approcher le son en lisant cette aide puis en écoutant ? La seule présence d’un champ ne valide pas l’aide.
5. Vérifier la même phrase et le même contrôle d’écoute sur ordinateur, web mobile et APK. Cette revue statique n’a pas établi que les assets d’un APK installé étaient identiques au dépôt.

Aucune proposition ne demande de supprimer la phonétique, de la masquer automatiquement ni de remplacer la méthode par le pinyin ou l’API. Le but est de rendre l’aide fiable et constante, en complément de l’écoute.
