# Melunga — L1 à L10, construire une maîtrise de la conversation

Proposition documentaire locale, 20 octobre 2026. À examiner avec Kartech et Claude. Aucun changement du contenu applicatif ou du site. Le contenu actuel reste la réserve de travail.

## Objectif fixé par Kartech

Les dix niveaux forment **un seul parcours cohérent**, fondé sur l’assemblage progressif de mots, de blocs et de structures. L10 doit viser une maîtrise fonctionnelle de la conversation quotidienne : comprendre, construire ses réponses et s’adapter à l’autre. Une amélioration de L1 seule ne suffirait pas.

Cette cible est une exigence de conception à vérifier par des essais. Achever dix listes ne démontre pas une maîtrise et ne garantit pas qu’une personne l’atteindra sans entraînement. « Maîtrise » désigne ici l’autonomie dans les situations quotidiennes couvertes, pas la connaissance de tous les mots ou de tous les usages professionnels d’une langue.

## Critères de sortie L10 proposés

Une personne qui a consolidé le parcours doit pouvoir, avec ses mots :

- comprendre l’essentiel d’un échange quotidien sur les thèmes travaillés, avec la possibilité naturelle de faire répéter ;
- exprimer un besoin, choisir, demander des renseignements et comprendre une réponse différente du modèle mémorisé ;
- parler de soi, du quotidien, d’événements passés et de projets ;
- expliquer une raison, comparer, donner un avis et répondre à une objection ;
- proposer, refuser poliment, négocier une alternative et confirmer un accord ;
- reconnaître un malentendu, demander une précision et reformuler ;
- maintenir plusieurs tours de conversation et réemployer les structures dans une situation nouvelle.

La phonétique et l’audio restent accessibles pour préparer, revoir et consolider. On observe séparément la réussite avec aide et la spontanéité en échange, sans supprimer automatiquement les aides ni appeler les deux résultats identiques. On ne mesure pas la maîtrise en vitesse de lecture ou en volume de cartes archivées.

## Colonne vertébrale proposée pour les dix niveaux

Chaque niveau comprend plusieurs séquences, des reprises et des situations variées. Les exemples français illustrent une compétence ; chaque langue a ses propres étapes grammaticales et usages naturels.

| Niveau | Capacité à construire | Acquis repris et difficulté ajoutée | Exemple d’autonomie attendue |
|---|---|---|---|
| **L1 — Premiers échanges** | Comprendre et réemployer des blocs utiles ; remplacer un élément | Quelques mots concrets et une structure à la fois ; saluer, remercier et demander de répéter disponibles comme blocs | Choisir sa boisson, la demander et comprendre un choix simple proposé par l’autre |
| **L2 — Enrichir sa phrase** | Ajouter une quantité, un lieu ou un moment, séparément | Reprendre les demandes et actions L1 ; un complément ou une distinction de construction par séquence | Demander une autre quantité ou situer une action avec des mots connus |
| **L3 — Faire circuler l’échange** | Passer de sa phrase à une question, répondre et relancer | Mêmes verbes/objets que L1–L2 ; personne, négation et question préparées successivement | Demander ce que l’autre souhaite, comprendre sa réponse puis répondre à son tour |
| **L4 — Parler de son quotidien** | Combiner des actions, personnes, lieux et habitudes | Réutiliser les questions et compléments ; enrichir famille, maison, activité et goûts progressivement | Décrire sa propre journée et répondre à des questions simples, sans réciter une biographie imposée |
| **L5 — Raconter ce qui s’est passé** | Situer des événements passés et enchaîner des actions | Partir d’actions L4 connues ; transformations temporelles/aspectuelles propres à la langue, puis négation et ordre des événements | Raconter une sortie personnelle et répondre à « où, quand, avec qui ? » |
| **L6 — Préparer la suite ensemble** | Parler d’intention/projet, inviter et ajuster | Réemploi des actions, moments et questions ; une façon de proposer, puis refus/alternative ; autres formulations ensuite | Organiser une sortie et trouver un autre horaire quand l’interlocuteur ne peut pas |
| **L7 — Expliquer ses choix** | Relier des idées, comparer et justifier | Réutiliser les propositions connues ; cause, comparaison et avis dans des séquences distinctes avant combinaison | Choisir logement, trajet ou activité, expliquer pourquoi et répondre à une autre préférence |
| **L8 — Adapter sa demande** | Nuancer, négocier et poser une condition concrète | Réemploi du besoin, projet, choix et raison ; registre, condition et lexique nouveau séparés au premier passage | Demander un changement, comprendre une limite et convenir d’une alternative réaliste |
| **L9 — Gérer l’imprévu** | Clarifier, reformuler et résoudre un problème à plusieurs étapes | Dépannage simple déjà connu depuis les niveaux bas ; incertitude et reformulation enrichies ; réponses moins prévisibles | Réagir à un transport annulé ou un rendez-vous mal compris, obtenir une précision puis choisir une solution |
| **L10 — Converser avec autonomie** | Choisir et combiner le répertoire L1–L9 selon son intention | Peu de nouvelles structures obligatoires ; contexte, interlocuteur et relances varient ; complexité davantage dans l’interaction que dans les mots rares | Entrer dans une discussion quotidienne, raconter, expliquer, répondre à une objection, réparer un malentendu et conclure un accord |

Les fonctions se rencontrent avant leur niveau d’approfondissement : une formule polie existe dès L1, une question simple aussi ; cela ne signifie pas qu’on exige déjà toutes les formes de politesse ou toutes les questions. De même, un bloc de secours ne doit pas attendre le niveau de résolution des incidents.

## Un fil rouge qui traverse les dix niveaux

Exemple illustratif autour de manger/sortir. Les formulations finales sont à adapter à chaque langue, au rôle et à la situation.

- **L1 :** « Un thé, s’il vous plaît. » → choisir une autre boisson connue.
- **L2 :** « Deux thés, s’il vous plaît. » → quantité ; dans une autre séquence, « Je mange à la maison. » → lieu, une fois l’action découverte.
- **L3 :** « Tu veux du thé ? » → comprendre et formuler une réponse, puis relancer.
- **L4 :** « Le soir, je mange à la maison avec ma famille. » → décrire sa réalité avec des briques préparées.
- **L5 :** « Hier, j’ai mangé au restaurant. Ensuite, je suis rentré. » → transformer des actions connues et les relier.
- **L6 :** « Demain, on va au restaurant ? » → comprendre le refus et proposer un autre moment.
- **L7 :** « Je préfère ce restaurant parce qu’il est près de chez nous. » → combiner choix et raison déjà accessibles.
- **L8 :** « Peut-on venir plus tard ? Si ce n’est pas possible, on peut venir demain. » → demande et alternative.
- **L9 :** « J’avais compris dix-neuf heures. Vous voulez dire que la réservation est à vingt heures ? » → réparer le malentendu et confirmer.
- **L10 :** organiser un repas avec plusieurs contraintes, expliquer une préférence, réagir à une objection et s’accorder sur une solution différente du dialogue modèle.

Ce n’est qu’un fil parmi d’autres. Le parcours doit reprendre le même mécanisme dans déplacements, maison, proches, travail courant, achats, santé de base et démarches ordinaires. Ne pas confondre « niveau avancé » avec jargon d’importation, production industrielle ou correspondance formelle : ces contenus utiles restent des spécialisations facultatives.

## Ce que l’audit actuel impose de revoir

1. **Aligner les trois progressions.** Les niveaux des cartes, du parcours guidé et de Mes phrases n’ont pas encore un contrat commun. Exemple : cause en L3 guidé et L7 conversation. Définir première rencontre et approfondissement avant de renuméroter.
2. **Séparer les familles qui mélangent les constructions.** « Je vais manger » et « Je vais mieux » ; « I think that… » et « I think about… » ne portent pas la même opération.
3. **Réduire les sauts cachés.** Le connecteur de cause ne devrait pas ajouter dès sa première découverte plusieurs temps inconnus ; un nouveau compteur ne devrait pas arriver avec quatre objets inconnus.
4. **Préparer ce que dit l’autre.** Le dialogue demande deux compétences : produire son intention et comprendre des réponses. Un modèle de commande n’enseigne pas automatiquement les nombres ou les questions de choix.
5. **Assurer le réemploi jusqu’à L10.** Une phrase dite connue ne doit pas disparaître de toute reprise lorsqu’elle sert de base à une nouvelle combinaison. La révision doit inclure les structures et pas seulement les phrases exactes.
6. **Créer des situations de transfert aux niveaux hauts.** Un dialogue entièrement écrit est un exemple ; il doit être complété par une tâche où l’apprenant choisit sa réponse parmi plusieurs possibilités pertinentes.
7. **Compléter la cohérence coréenne.** Le catalogue et les dix niveaux conversation existent ; la configuration du parcours classique par familles manque dans la copie analysée.

## Contrat de préparation proposé à Claude pour chaque niveau

Avant réalisation, fournir une fiche documentaire par niveau, et par langue si les étapes diffèrent :

| Champ | Ce qu’il doit expliquer |
|---|---|
| Capacité de sortie | Ce que l’apprenant peut faire dans une vraie interaction |
| Prérequis précis | Quelles séquences antérieures fournissent mots et structures nécessaires |
| Nouveauté principale | Transformation visée, avec les autres difficultés séparées |
| Variations proches | Substitutions et compléments corrects, adaptés à la langue |
| Réemploi antérieur | Au moins des reprises identifiables, sans quota présenté comme vérité pédagogique |
| Oral reçu | Questions, réponses et relances que l’apprenant doit comprendre |
| Transfert | Une situation/combinaison différente du modèle récité |
| Consolidation | Où la structure revient ensuite, jusqu’aux tâches L10 |
| Aides | Audio/phonétique/modèle disponibles selon le besoin, puis essai avec moins d’appui |
| Enrichissement | Contenus existants plus spécialisés conservés hors du passage principal |

Commencer par **la carte complète des dix niveaux** et leurs liens, puis tester quelques transitions représentatives : L1→L2, L4→L5, L6→L7, L9→L10. Un essai L1–L3 sert à régler l’entrée ; il ne remplace pas la validation de la montée complète vers L10.

Pour chaque transition, conserver le vocabulaire autant que possible, puis faire varier la nouvelle opération. Une fois celle-ci comprise, élargir le vocabulaire et le contexte. Éviter d’imposer les mêmes découpages grammaticaux à toutes les langues.

## Validation sur les trois supports

Le même objectif et les mêmes étapes s’appliquent à l’ordinateur, au site mobile et à l’application Android. Les adaptations d’écran et de geste ne doivent pas modifier les prérequis ni retirer des aides. Après accord sur les propositions, des versions d’essai séparées permettront de vérifier compréhension, réemploi et continuité. Rien ne sera mis en ligne sans validation explicite de Kartech.

## Message prêt à transmettre à Claude

> Kartech précise la cible : conserver et améliorer le contenu, avec une progression cohérente de L1 à L10 fondée sur l’assemblage de mots, blocs et structures. L10 doit viser une autonomie réelle dans les conversations quotidiennes, avec compréhension, réponses personnelles, récit, projets, raisons, négociation et réparation des malentendus. Préparons d’abord une carte des dix niveaux : capacité de sortie, prérequis précis, nouveauté principale, réemploi des acquis et tâche de transfert. Distinguer première rencontre d’une fonction et approfondissement ; séparer les familles qui mélangent les constructions ; conserver les phrases plus riches en enrichissement. Les trois ensembles (cartes, guidé, Mes phrases) doivent soutenir ce même chemin, sur ordinateur, site mobile et application. Ensuite, essais des transitions clés, pas seulement de L1. Aucune modification applicative, fusion ou publication pour cette proposition sans validation de Kartech.

## Règle précisée par Kartech : les leçons sont faites de phrases

La phrase utile en contexte est l’unité principale de chaque leçon, dès L1. Elle est affichée, traduite, accompagnée de la phonétique adaptée au lecteur et prononçable en entier. Les mots et morceaux remplaçables sont découverts dans une phrase ; une liste de mots ou de règles ne remplace pas la leçon. Les rubriques de vocabulaire servent à retrouver des briques avec leurs phrases d’emploi.

Exemple de chaîne illustrative : « Je veux de l’eau. » → « Je veux du thé. » → « Je veux boire. » → « Je veux boire du thé. » → « Tu veux boire du thé ? ». Chaque changement de construction est préparé dans une séquence distincte. La phrase complète correcte fait autorité, avec les adaptations propres à chaque langue.

Cette règle concerne les leçons classiques autant que Mes phrases, les révisions, les thèmes et les dialogues, sur les trois supports. Les expressions courtes naturelles (« Bonjour », « Merci ») restent possibles comme répliques en situation, sans imposer artificiellement un sujet et un verbe à chaque échange.
