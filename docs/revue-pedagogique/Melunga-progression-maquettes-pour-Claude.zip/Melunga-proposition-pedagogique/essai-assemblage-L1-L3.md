# Essai documentaire — construire une conversation L1–L3

Proposition locale pour Kartech et Claude. Aucun fichier applicatif modifié, aucune publication. Les phrases chinoises proposées demandent une relecture native avant livraison ; le pinyin est une aide de lecture, pas une transcription phonétique francophone validée. Les enregistrements audio restent à vérifier. Les étapes décrivent un chemin pédagogique, pas des écrans à coder sans validation.

## Cadre commun

L1 : obtenir une boisson et comprendre une proposition. L2 : préciser une quantité puis ce qu’on souhaite faire. L3 : demander à l’autre, répondre et proposer une activité.

Chaque ligne ci-dessous est une petite séquence distincte, pas une liste à mémoriser dans une séance. Commencer par écouter et comprendre, puis imiter, remplacer, retrouver avec moins d’aide. Reprendre les acquis au début de la séquence suivante. N’ajouter une difficulté que lorsque l’essai montre que la précédente est suffisamment accessible ; aucun seuil automatique n’est défini ici.

« Bonjour », « merci », « non merci », ainsi qu’une formule pour demander de répéter, sont disponibles très tôt comme blocs contextualisés. Leur grammaire n’a pas besoin d’être analysée immédiatement. Préparer les deux côtés de l’échange avant de cacher un rôle.

## Parcours espagnol pour francophones

| Étape | Phrase entendue et comprise | Construction attendue | Nouveauté principale |
|---|---|---|---|
| L1-A | Quiero agua. — Je veux de l’eau. | Réutiliser la phrase dans une scène de choix de boisson | Quiero + eau |
| L1-B | Quiero té. — Je veux du thé. | eau → thé, puis retrouver l’une des deux selon l’image | Un nom nouveau dans la même structure |
| L1-C | Agua, por favor. — De l’eau, s’il vous plaît. | Té, por favor. ; réponse Gracias. | Demande polie comme bloc réutilisable |
| L1-D | ¿Agua o té? — De l’eau ou du thé ? | Répondre Quiero agua/té, puis employer une réponse courte naturelle | Comprendre le choix proposé ; o = ou |
| L2-A | Un té, por favor. — Un thé, s’il vous plaît. | Dos tés, por favor. | Quantité et pluriel, avec la même boisson |
| L2-B | Quiero comer. — Je veux manger. | Quiero beber. — Je veux boire. | Quiero + action ; deux actions introduites successivement |
| L2-C | Quiero beber agua. — Je veux boire de l’eau. | Quiero beber té. | Combiner action connue + boisson connue |
| L2-D | Quiero comer pan. — Je veux manger du pain. | Ajouter un aliment déjà découvert à l’écoute, par exemple arroz | Compléter comer ; introduire pan puis arroz séparément |
| L3-A | ¿Quieres agua? — Tu veux de l’eau ? | Répondre Sí, gracias. / No, gracias. | Quiero → quieres et forme interrogative |
| L3-B | ¿Quieres beber agua? — Tu veux boire de l’eau ? | ¿Quieres beber té? | Combiner question connue + action connue |
| L3-C | ¿Quieres comer? — Tu veux manger ? | Accepter ou refuser ; reconnaître la différence manger/boire | Transfert sans nouveau vocabulaire principal |
| L3-D | ¿Comemos juntos? — On mange ensemble ? | Comprendre puis proposer ; Sí, claro. — Oui, bien sûr. | Invitation comme nouveau bloc, après les questions précédentes |

Précautions : « Quiero » sert ici à construire le sens, mais une commande réelle peut être formulée plus naturellement par « Un té, por favor ». Ne pas présenter « Quisiera » comme une obligation dès qu’une quantité est ajoutée : cela ferait changer à la fois quantité et forme verbale. Introduire cette nuance dans une autre séquence. « ¿Quieres…? » relève du tutoiement ; ne pas mélanger immédiatement avec usted.

## Parcours mandarin pour francophones

| Étape | Phrase — pinyin — sens | Construction attendue | Nouveauté principale |
|---|---|---|---|
| L1-A | 我要水。— wǒ yào shuǐ — Je veux de l’eau. | Comprendre et réutiliser le bloc en contexte familier | 我要 + eau |
| L1-B | 我要茶。— wǒ yào chá — Je veux du thé. | eau → thé | Un nom nouveau, sans compteur |
| L1-C | 请给我水。— qǐng gěi wǒ shuǐ — Donnez-moi de l’eau, s’il vous plaît. | 请给我茶。; 谢谢。— xièxie — Merci. | Nouvelle demande polie, travaillée séparément |
| L1-D | 水还是茶？— shuǐ háishi chá — De l’eau ou du thé ? | Répondre 我要水/我要茶, puis réponse courte 水/茶 | Comprendre un choix ; 还是 appris dans cette question |
| L2-A | 一杯茶。— yì bēi chá — Une tasse de thé. | 我要一杯茶。 | Unité 杯, d’abord avec 一 et une boisson connue |
| L2-B | 我要两杯茶。— wǒ yào liǎng bēi chá — Je veux deux tasses de thé. | 一杯 → 两杯, puis eau/thé | 两 devant le compteur ; ne pas ajouter 张/个 ensemble |
| L2-C | 我想喝水。— wǒ xiǎng hē shuǐ — J’ai envie de boire de l’eau. | 我想喝茶。 | Découvrir 想喝 comme bloc, puis distinguer 想 et 喝 progressivement |
| L2-D | 我想吃米饭。— wǒ xiǎng chī mǐfàn — J’ai envie de manger du riz. | Réutiliser 我想 + action ; autre aliment connu seulement ensuite | D’abord 吃 puis 米饭, dans deux moments de découverte si nécessaire |
| L3-A | 你要水吗？— nǐ yào shuǐ ma — Tu veux de l’eau ? | 要，谢谢。— yào, xièxie ; 不要，谢谢。— bú yào, xièxie | 我 → 你 et question en 吗, présentés en deux passages |
| L3-B | 你想喝茶吗？— nǐ xiǎng hē chá ma — Tu as envie de boire du thé ? | Remplacer 茶 par 水 ; répondre 想/不想 dans ce contexte | Transfert de la question ; réponse liée au verbe entendu |
| L3-C | 你想吃米饭吗？— nǐ xiǎng chī mǐfàn ma — Tu as envie de manger du riz ? | Comprendre manger/boire et répondre avec aide puis sans aide | Réemploi de mots connus |
| L3-D | 一起吃饭，好吗？— yìqǐ chī fàn, hǎo ma — On mange ensemble, d’accord ? | Comprendre et accepter : 好。— hǎo — D’accord. | Invitation comme bloc ; distinguer 吃饭 de 吃米饭 |

Précautions : 我要 n’est pas une formule universelle de commande polie. Le contexte, l’intonation et les formules de demande sont montrés dès le départ. Ne pas traduire mécaniquement « vouloir » par 要 dans tous les contextes : 想 + action fait ici l’objet d’une découverte propre. 吃饭 signifie manger/prendre un repas, tandis que 吃米饭 précise manger du riz. « Oui/non » n’est pas systématiquement 是/不是 : préparer des réponses adaptées à la question. Ne pas demander la lecture autonome des caractères pour réussir un exercice oral. Les tons et changements de ton sont appris à partir d’un audio contrôlé ; la transcription ne remplace pas cet audio.

## Exemple de maquette textuelle, sans modification d’interface

### Découverte

Contexte visuel : deux personnes choisissent une boisson.

**我要水。**

wǒ yào shuǐ

Je veux de l’eau.

[Écouter] puis possibilité de répéter. Le sens reste accessible.

### Assemblage guidé

Même contexte. L’apprenant choisit l’image du thé, déjà découvert.

**我要 [茶]。**

La phrase entière est affichée et prononcée ; la case ne doit pas suggérer que n’importe quel mot peut s’y insérer.

### Petit échange, après préparation

Interlocuteur : **水还是茶？**

Apprenant : choisit une boisson et répond ; le modèle peut être révélé. Au premier passage, l’échange complet a été entendu et vu. Au rappel seulement, la réponse peut être masquée.

### Transfert

Autre scène, mêmes mots : obtenir du thé plutôt que de l’eau, sans recopier une phrase affichée. Ajouter ensuite une nouvelle boisson seulement après sa découverte. Le scénario n’exige pas de reconnaissance vocale automatique.

## Vérification de l’assemblage

Ne pas enseigner un simple collage universel :

- Espagnol : Quiero + beber + agua → Quiero beber agua. Mais Quiero + agua + beber ne donne pas la phrase travaillée.
- Français : « de l’eau » devient « du thé » ; la phrase complète gère les déterminants.
- Chinois : 一杯茶 → 两杯茶 ; éviter d’enseigner 二杯茶 comme variante standard de ce modèle.
- Chinois : 你要水吗？ et 水还是茶？ ne s’assemblent pas en ajoutant 吗 à la question alternative comme si les deux mécanismes étaient interchangeables.

Ces contre-exemples servent à la vérification éditoriale. Ne pas les afficher systématiquement au débutant, au risque de lui faire mémoriser une forme incorrecte.

## Essai à mener avec Kartech et son épouse

Noter, pour chaque étape : question comprise ou non, réponse avec/sans modèle, aide utilisée, mot ou geste bloquant. Revenir sur les mêmes mots après une interruption et dans une autre scène. Distinguer compréhension, répétition et création d’une variante : ce sont des capacités différentes.

Si une étape bloque, isoler la difficulté : mot nouveau, son, consigne, choix d’interface ou structure. Réduire la nouveauté avant d’ajouter plus d’exemples. La vitesse de lecture n’est pas le critère principal de réussite orale.

## Transmission proposée à Claude

Préparer d’abord ces séquences en document de travail, corriger leur naturel avec une relecture native, et relever les phrases déjà présentes dans la réserve. Ne pas réécrire massivement les niveaux ni changer le schéma avant l’essai validé par Kartech. Les modèles actuels peuvent servir de réserve et d’enrichissement ; cette proposition concerne leur ordre d’apprentissage. Aucune fusion, publication ou mise en production autorisée.
