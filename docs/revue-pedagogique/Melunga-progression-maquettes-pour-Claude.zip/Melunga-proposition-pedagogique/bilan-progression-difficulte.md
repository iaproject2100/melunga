# Melunga — bilan de progression et de difficulté

Revue locale du 20 octobre 2026. Priorité exprimée par Kartech : apprentissage par assemblage progressif de mots, blocs et structures pour créer ses propres phrases. Conserver le contenu et améliorer son organisation. Aucun contenu applicatif, aucune branche distante et aucun site modifiés.

## Objectif prioritaire précisé par Kartech

La progression entière L1–L10 doit mener à une maîtrise fonctionnelle de la conversation quotidienne. La proposition de capacités par niveau, critères de sortie L10 et essais des transitions se trouve dans `progression-L1-L10-vers-maitrise.md`. Le pilote débutant ne remplace pas cette cohérence globale.

## Conclusion

**La réserve de contenus peut être conservée. Le chemin d’apprentissage doit être amélioré avant de considérer L1–L10 comme une progression régulière.**

Le principe de Melunga apparaît déjà dans les familles de phrases et les variantes de « Mes phrases ». Cependant, un regroupement par mots ressemblants ne garantit pas une même structure productive. L’ordre doit montrer ce que l’apprenant sait déjà, ce qu’il transforme et comment il réutilise l’ensemble pour répondre à quelqu’un.

L’ajout massif de phrases n’est pas la priorité. La première amélioration serait une sélection progressive dans la réserve, avec des ponts entre structures et des révisions contextualisées. Une phrase déplacée reste disponible dans la bibliothèque ou en enrichissement.

## Périmètre et limites

Source analysée : copie locale `feat/conversation-integration`, commit `49dca94`. Elle contient des travaux d’essai et ne doit pas être assimilée à la version actuellement publiée sur melunga.com ou à une APK donnée.

- Inventaire automatisé des 32 115 entrées des sept catalogues classiques et des 70 fichiers conversation L1–L10.
- Lecture des familles du parcours guidé : 26 familles et 151 occurrences par langue pour six langues (fr, en, es, zh, it, ja). Les répétitions volontaires entre familles expliquent que le nombre de phrases distinctes soit inférieur à 151. Pas de configuration coréenne dans ce parcours guidé, alors que le catalogue et les dix niveaux conversation coréens existent.
- Revue pédagogique des objectifs et exemples de chaque niveau, des familles et de leurs transitions ; revue détaillée de situations conversation et d’échantillons de cartes classiques. Les sources détaillées sont dans les rapports joints.
- Les 70 JSON passent le validateur structurel existant : champs, références et minimums. Cela ne valide ni la difficulté ni l’efficacité de la méthode.
- Ce bilan n’est pas une relecture linguistique exhaustive des 32 115 entrées ni une mesure expérimentale d’apprentissage. Aucun niveau CECRL/HSK ou pourcentage de conversations couvertes n’est certifié.
- La phonétique, les traductions, le design et l’architecture restent hors de la priorité actuelle, sauf quand leur fonctionnement ajoute une difficulté au parcours.

## Trois ensembles à faire converger

| Ensemble | Intérêt | Risque pour l’apprenant |
|---|---|---|
| Cartes classiques L1–L10 | Grande réserve de phrases et thèmes utiles | Le numéro d’une carte ne dit pas quelles briques ont été préparées ; L1 contient 224 à 318 cartes core selon la langue |
| Parcours guidé par familles | Sélection plus courte et regroupements propices au réemploi | Des familles mélangent des constructions ou des usages ; certains exemples sont trop avancés pour l’étape annoncée |
| Mes phrases L1–L10 | Modèles, variantes, rappel et dialogues ; rôles contextualisés | Les dialogues demandent parfois plus que les variantes préparatoires ; ses niveaux n’ont pas le même programme que le parcours guidé |

Ces volumes décrivent des catalogues, pas ce que l’application oblige à apprendre en une séance. Le problème est le chemin entre les éléments, pas le volume en soi.

Exemple de désalignement : la cause se trouve en L3 dans le parcours guidé, mais constitue un objectif L7 dans la matrice conversation. Ce choix peut être légitime si l’on distingue cause simple et justification développée ; cette distinction n’est pas suffisamment explicitée actuellement. Il ne faut pas supposer que les numéros identiques impliquent les mêmes acquis.

## Les difficultés les plus importantes

### 1. Une même apparence n’est pas toujours une même construction

Preuves dans `PEDAGOGY_FAMILIES`, intégré à `app.html` :

| Famille | Exemple à isoler | Pourquoi il gêne l’assemblage | Proposition à tester |
|---|---|---|---|
| fr `L2_ACTION_PROCHE`, « Je vais + action » | Je vais mieux. | « mieux » n’est pas une action à l’infinitif ; le sens de « aller » change | Garder en bloc « état/santé », hors de cette série productive |
| en `L2_ACTION_PROCHE`, « I’m going to + action » | I’m going to bed. | Déplacement vers un lieu, alors que « I’m going to eat » construit une intention/action | Deux séries reliées mais distinctes, avec exemples simples |
| es `L2_ACTION_PROCHE` | Voy a casa. / Voy a por agua. | Destination et tournure péninsulaire « aller chercher » ne se transforment pas comme « voy a descansar » | Séparer action, destination puis expression « aller chercher » |
| zh `L2_ACTION_PROCHE`, « 我要 + 动作 » | 我要两个 / 我要这个 | Quantité ou objet après 要, pas une action | Apprendre les deux usages en étapes distinctes, avec leur sens |
| fr `L4_CONDITION` | Signez ici, s’il vous plaît. | « s’il vous plaît » n’exerce pas la condition présentée | Conserver en demande polie, pas en exemple de « si… » |
| en `L6_OPINION` | I think about you. / I believe in you. | Penser à / croire en ne donnent pas le patron « I think [that] + proposition » | Garder en autres familles, sans les mélanger au premier apprentissage de l’opinion |
| it `L4_CONDITION` | Secondo me, è un errore. | Opinion et non condition | Reclasser dans l’opinion |
| ja `L9_HYPOTHESE` | もしかすると、明日は雨かもしれません。 | Possibilité/incertitude plutôt que la condition de la famille | Réemploi dans la famille de probabilité |

Ces phrases peuvent être correctes et utiles. C’est leur rôle d’exemple de la construction annoncée qui pose problème.

### 2. Une seule nouveauté principale n’est pas encore respectée régulièrement

- fr L3 cause : « Je mange parce que j’ai faim » côtoie « Je suis resté parce que j’avais promis ». On ajoute passé composé et plus-que-parfait au moment d’apprendre la relation de cause.
- en L3 cause : « I’m eating because I’m hungry » côtoie « I stayed because I had promised » puis un passif « The match was cancelled because of the rain ». Plusieurs mécanismes concurrents, dont because / because of.
- es L2 demande : « Quisiera unas muestras », « Me gustaría poder ir » et « Quisiera agradecerles su presencia » combinent commande professionnelle, verbes imbriqués et registre cérémoniel.
- it L3 cause : « Sono rimasto perché avevo promesso » et « Perché vuole entrare nella nostra azienda? » ne travaillent pas la même tâche : expliquer une raison puis répondre à un entretien.
- zh L3 cause : « 我回家，因为太晚了 » côtoie « 正因为难，才值得做 » : emphase, nouveau vocabulaire et construction 正因为…才… supplémentaires.
- ja L2 désir : « 眠りたいです » côtoie « OEM生産をしたいです » : le patron est reconnaissable mais le lexique professionnel ajoute une difficulté étrangère au besoin quotidien débutant.

Pour un premier passage, garder les deux parties déjà connues, puis introduire seulement le connecteur ou la transformation. Les exemples plus riches deviennent un deuxième passage ou un enrichissement.

### 3. Le débutant reçoit trop de familles indépendantes avant d’avoir un petit pouvoir de conversation

Mes phrases L1 a onze modèles et quatre variantes chacun : c’est une bonne réserve, pas nécessairement un bon premier itinéraire. Identité, besoin, commande, prix, goût, lieu et sensation doivent former plusieurs petites séquences.

Exemple chinois : préparer « 我要一张票 » ne prépare pas automatiquement la réplique de gare « 我需要一张去上海的票 ». S’ajoutent le verbe du besoin, la destination et le groupe déterminant le billet. Il faut un pont explicite ou une première réplique plus simple lors de l’essai.

Un petit échange ne devient pas facile parce qu’il contient seulement quelques lignes. Les questions et réponses de l’interlocuteur doivent, elles aussi, être découvertes avant la réponse masquée.

### 4. La difficulté dépend de plusieurs dimensions

Pour chaque phrase d’exercice, distinguer :

- les mots et blocs nouveaux ;
- la transformation grammaticale ou l’ordre des éléments ;
- la longueur et le nombre d’idées ;
- la tâche : écouter, reconnaître, imiter, rappeler, créer, répondre à une surprise ;
- le contexte et le registre : familier, poli, métier, administratif ;
- les aides disponibles et la familiarité avec les sons.

Une phrase longue avec des blocs familiers peut être plus accessible qu’une particule courte sans contexte. Passer de la répétition à une réponse masquée peut augmenter la difficulté même sans nouveau mot. Aucun score de longueur ne suffirait à classer les contenus.

## Revue des dix niveaux : objectif à clarifier, contenu à garder

Cette grille rapproche les trois ensembles sans prétendre qu’ils ont actuellement le même programme. Il s’agit d’une direction à essayer, pas d’une nouvelle classification déjà validée.

| Niveau | Diagnostic | Amélioration par assemblage | Indice à observer en essai |
|---|---|---|---|
| L1 | Trop de fonctions simultanées ; certaines premières variantes sont spécialisées | Quelques blocs quotidiens et une structure productive par mini-séquence ; changer un élément connu | Comprendre une question préparée et choisir sa propre réponse simple |
| L2 | Action, destination, quantité et désir se mélangent ; lexique parfois professionnel | Compléter une structure connue, puis apprendre séparément à passer d’un nom à une action | Produire une combinaison non recopiée avec les briques déjà vues |
| L3 | Les connecteurs du guidé s’accompagnent parfois de temps complexes ; les questions du conversation ajoutent plusieurs formes | Transformer et échanger avec vocabulaire connu ; si une cause simple est introduite, les deux idées sont déjà familières | Question et réponse compréhensibles sans nouveau modèle complet à chaque fois |
| L4 | Quotidien dans conversation ; conditions parfois hypothétiques ou complexes dans le guidé | Consolider une journée personnelle et enrichir lieu/moment/personne ; condition concrète préparée séparément | Réutiliser les mêmes actions dans plusieurs petites scènes |
| L5 | Récit au passé dans conversation ; temps/permission/obligation dans guidé, avec mélanges de formes | Une transformation temporelle sur une action connue, puis négation et enchaînement ; demander permission en famille distincte | Parler d’une action passée familière sans ajouter simultanément beaucoup de vocabulaire |
| L6 | Projets/opinions/choix/conseils selon les ensembles ; plusieurs synonymes et sens différents | Passer d’une action connue à un projet, une invitation, un choix ; une nouvelle opération à la fois | Accepter/refuser puis proposer une alternative préparée |
| L7 | Raisons, habitudes passées, discours rapporté et séquences peuvent devenir plusieurs cours en un | Relier des idées déjà maîtrisées, comparer, puis réutiliser pour expliquer un changement | Donner une raison personnelle avec des éléments familiers |
| L8 | Concession ou négociation ; gros renouvellement administratif et professionnel possible | Adapter une demande connue, négocier une variable, puis condition ; les demandes polies simples existent déjà plus tôt | Modifier prix/moment/lieu sans réciter tout un dialogue |
| L9 | Probabilité, hypothèse, clarification et imprévu ; certains blocs de secours apparaissent tard | Réparer un échange à partir des formules simples vues tôt ; problème à plusieurs étapes | Demander une précision et choisir une solution alternative |
| L10 | Reprises utiles mais aussi fragments de discours et registre plus élevé | Combiner librement récit, choix, raison et clarification dans de nouvelles situations | Plusieurs réponses plausibles ; maintenir l’échange et s’adapter à une relance |

Le passage à un niveau plus haut ne doit pas obligatoirement allonger chaque phrase. On peut garder une phrase simple et demander un réemploi plus autonome. Ces niveaux restent des niveaux Melunga, pas des équivalences certifiées avec un référentiel externe.

## Points propres aux sept langues

| Langue étudiée | Point essentiel pour la difficulté d’assemblage |
|---|---|
| Français | Articles/élisions et place des pronoms ; séparer « je vais + lieu », « je vais + infinitif » et les expressions d’état. Garder la phrase complète correcte après remplacement. |
| Anglais | Différencier destination/intention, question/affirmation et think about / think that. Éviter d’ajouter passé, passif et expressions idiomatiques à la première relation de cause. |
| Espagnol | Conjugaison de la question et pronoms attachés ; différencier voy a + lieu/action et a por. Introduire les formes de politesse et hypothèses en étapes, sans les empiler. |
| Italien | Alterner les éléments familiers avant clitiques, temps composés et hypothèses. Les exemples « puoi dirglielo » ou « se avessi saputo, sarei venuto » sont des enrichissements après préparation. |
| Mandarin | Ordre des groupes, question reçue, classificateurs et usages différents de 要/想. Introduire progressivement les blocs ; éviter les structures emphatiques ou commerciales comme premier contact avec une famille. |
| Japonais | Ordre différent du français, particules, formes verbales et registres. Une substitution ne se fait pas toujours après un début de phrase invariant ; employer des phrases complètes validées et des séries vraiment comparables. |
| Coréen | Particules et terminaisons adaptées ; préparer une réponse naturelle à la question. Le contenu conversation existe, mais le parcours guidé par familles n’a pas de configuration ko dans cette copie : la progression n’y est pas au même stade que dans les six autres langues. |

La compétence visée peut être commune ; le nombre d’étapes intermédiaires ne doit pas être imposé identique dans toutes les langues. L’aide phonétique reste disponible : sa présence ne dispense pas de préparer les blocs, et son retrait ne doit pas être confondu avec une augmentation obligatoire de niveau.

## Progression réellement utile : quels signes chercher ?

« Je connais » et le nombre de cartes vues renseignent un choix de l’apprenant, pas la capacité démontrée à créer une phrase. Pour une famille, observer séparément :

1. comprendre la phrase et la réponse de l’autre ;
2. imiter puis répéter avec l’aide nécessaire ;
3. remplacer un élément connu ;
4. retrouver une phrase après une interruption ;
5. recombiner des éléments connus dans une phrase qui n’a pas été copiée ;
6. l’employer dans un autre contexte et comprendre une relance préparée.

Ne pas en faire six obstacles obligatoires ou un examen permanent. Ces repères servent à régler les aides et à proposer une reprise. La vitesse n’est pas une preuve suffisante de maîtrise. Un bouton de reconnaissance vocale ne valide pas à lui seul grammaire, sens et capacité de conversation.

## Même progression sur ordinateur, site mobile et application

Les contenus, prérequis, exemples et critères d’essai doivent être les mêmes. Leur présentation peut s’adapter. La différence de taille d’écran ne doit pas modifier l’ordre des briques ou transformer une découverte en rappel sans aide.

L’essai doit vérifier sur chaque support : phrase complète lisible, aide phonétique accessible, écoute utilisable, choix compréhensible, réponse révélable après tentative, absence de contrainte de geste ou de lecture supplémentaire qui ferait croire à une difficulté linguistique. Ce sont des points d’essai proposés, pas des constats de tests sur téléphone effectués dans cette revue.

## Répartition proposée avec Claude, après validation de l’essai

1. **Codex** fournit les familles à séparer, les sauts de difficulté et les critères d’essai ; documente un petit scénario commun aux trois supports.
2. **Claude** propose, à partir du contenu existant, un ordre de mini-séquences et les phrases de transition manquantes. Chaque séquence indique briques déjà vues, nouveauté principale et réponse de l’interlocuteur.
3. **Kartech** essaie et valide une chaîne courte L1–L3 en chinois et espagnol avant extension.
4. **Revue commune** des ajustements ; ensuite seulement décision de les représenter dans les données et les interfaces.

Pas d’ajout immédiat d’un nouveau schéma, de nouvelles règles de déblocage ou d’une note de maîtrise. Ne pas reclasser automatiquement les 32 115 entrées. On peut d’abord améliorer une sélection et préserver tous les accès à la bibliothèque.

Message à transmettre :

> Le contenu reste une réserve à conserver. Notre priorité est de rendre la difficulté progressive selon la méthode d’assemblage de Kartech : une structure claire, des briques connues, une nouveauté principale, puis une combinaison nouvelle et un petit échange préparé. Corrigeons d’abord les familles qui mélangent les usages (ex. « Je vais manger / Je vais mieux »), les sauts de grammaire et les dialogues insuffisamment préparés. Préparons une proposition documentaire L1–L3 chinois/espagnol, adaptée à l’ordinateur, au site mobile et à l’application. Aucune modification en ligne, fusion ou publication sans validation de Kartech.

## Pièces locales

- `progression-L1-L10-vers-maitrise.md` : cible L10, progression complète et contrat de préparation proposé à Claude.

- `inventaire-progression.json` : volumes des catalogues, familles et conversations.
- `essai-assemblage-L1-L3.md` : exemples de séquences chinois/espagnol.
- Rapports de relecture spécialisés : à lire pour les preuves détaillées, en gardant la progression comme priorité.
