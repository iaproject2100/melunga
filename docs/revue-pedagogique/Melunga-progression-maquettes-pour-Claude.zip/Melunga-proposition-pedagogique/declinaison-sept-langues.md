# Déclinaison de la progression dans les sept langues

Proposition locale pour Kartech et Claude — 20 octobre 2026. Aucun contenu supprimé, aucune donnée ou interface modifiée, aucune publication. Sources : `modeles-progression-source.json`, extrait local des modèles conversation existants. Les exemples cités sont présents dans la réserve : ils servent à préparer une progression, pas à certifier qu’une variante nouvelle serait correcte sans relecture.

## Couverture et statut

Les dix niveaux sont pris en compte dans le cadre commun ci-dessous. Quatre ponts particulièrement utiles sont ensuite explicités pour chaque langue. L2 et L8 ne sont pas omis : L2 est la préparation interne du pont L1–L3 ; L8 constitue le passage des justifications L7 aux résolutions L9. La difficulté grammaticale n’est pas supposée identique d’une langue à l’autre.

| Langue étudiée | Lecteur des contenus actuels | L1–L3 | L4–L5 | L6–L7 | L8 | L9–L10 | Statut |
|---|---|---|---|---|---|---|---|
| Français | Sinophone | Remplacer, compléter, échanger | Quotidien → passé | Projet → raison/comparaison | Adapter et poser une condition | Clarifier → combiner librement | Proposition documentaire ; essai et relecture à valider |
| Anglais | Francophone | Remplacer, compléter, échanger | Quotidien → passé | Projet → raison/comparaison | Adapter et poser une condition | Clarifier → combiner librement | Proposition documentaire ; essai et relecture à valider |
| Espagnol | Francophone | Remplacer, compléter, échanger | Quotidien → passé | Projet → raison/comparaison | Adapter et poser une condition | Clarifier → combiner librement | Proposition documentaire ; essai et relecture à valider |
| Italien | Francophone | Remplacer, compléter, échanger | Quotidien → passé | Projet → raison/comparaison | Adapter et poser une condition | Clarifier → combiner librement | Proposition documentaire ; essai et relecture à valider |
| Mandarin | Francophone | Remplacer, compléter, échanger | Quotidien → passé | Projet → raison/comparaison | Adapter et poser une condition | Clarifier → combiner librement | Proposition documentaire ; essai et relecture à valider |
| Japonais | Francophone | Remplacer, compléter, échanger | Quotidien → passé | Projet → raison/comparaison | Adapter et poser une condition | Clarifier → combiner librement | Proposition documentaire ; essai et relecture à valider |
| Coréen | Francophone | Remplacer, compléter, échanger | Quotidien → passé | Projet → raison/comparaison | Adapter et poser une condition | Clarifier → combiner librement | Proposition documentaire ; essai et relecture à valider |

## Fil commun des dix niveaux

| Niveau | Opération dominante | Préparation nécessaire |
|---|---|---|
| L1 | Comprendre un besoin et réutiliser un bloc avec un autre mot | Sens et écoute accessibles ; petit échange visible avant rappel |
| L2 | Préciser ce bloc : quantité, lieu ou moment | Une dimension à la fois ; mots réutilisés |
| L3 | Transformer pour questionner, répondre et relancer | Question reçue et réponse préparées, avec formes propres à la langue |
| L4 | Combiner pour décrire son quotidien | Actions et compléments familiers, puis fréquence |
| L5 | Reprendre ces actions pour raconter un événement | Repères temporels puis formes de temps/aspect en contexte |
| L6 | Réemployer pour un projet et une proposition | Intention, invitation et réponse travaillées séparément |
| L7 | Relier des idées et comparer | Deux propositions accessibles avant de les relier ; une opération par séquence |
| L8 | Adapter une demande et poser une condition | Demande simple connue, puis alternative, puis condition |
| L9 | Réparer une incompréhension et résoudre un imprévu | Dépannage simple connu depuis le début ; ici développement de la situation |
| L10 | Choisir et combiner les acquis dans une conversation nouvelle | Plusieurs réponses plausibles ; moins d’aide selon le besoin, aucune suppression forcée |

Un numéro de niveau n’est pas une preuve de maîtrise, ni une équivalence CECRL. Des demandes simples, salutations et formules de secours restent accessibles tôt même si leurs versions développées sont travaillées tard.

## Français pour sinophones

| Pont | Appuis existants dans les contenus | Étapes à préparer |
|---|---|---|
| L1 → L3 | `L1-zh-fr-03` : « Je veux un café. » → `L2-zh-fr-01` : « Je voudrais deux cafés, s'il vous plaît. » → `L3-zh-fr-02` : « Tu peux venir ? » | Conserver « Je veux… », travailler quantité et politesse dans deux petites séquences. Introduire tu/vous en contexte et la question reçue avant de demander une transformation autonome. |
| L4 → L5 | `L4-zh-fr-06` : « Je travaille dans une banque. » → `L5-zh-fr-01` : « Hier, j'ai travaillé. » | Reprendre travailler avec le même lieu et le même sujet ; isoler hier + passé composé avant de cumuler les auxiliaires avoir/être, la négation et plusieurs actions. |
| L6 → L7 | `L6-zh-fr-06` : « Je ne peux pas, mais dimanche c'est possible. » → `L7-zh-fr-01` : « Je prends le métro parce que c'est rapide. » | Reprendre une proposition et sa réponse connues ; ajouter une cause courte, puis comparer séparément. Le travail du pronom/sujet et des contractions ne doit pas ajouter une difficulté cachée. |
| L9 → L10 | `L9-zh-fr-07` : « Si j'ai bien compris, je dois revenir demain ? » → `L10-zh-fr-03` : « Si je comprends bien, tu penses que c'est une bonne idée. » | Transformer une vérification concrète en reformulation de l’avis de l’autre. Conserver une vraie réponse ouverte ; ne pas évaluer par récitation d’un long cadre. |

**Passage par L8.** En L8, enrichir une demande connue avant « Pourriez-vous… », puis introduire une condition ; une demande polie simple reste disponible bien avant L8.

## Anglais pour francophones

| Pont | Appuis existants dans les contenus | Étapes à préparer |
|---|---|---|
| L1 → L3 | `L1-fr-en-03` : « I want a coffee. » → `L2-fr-en-01` : « I'd like two coffees, please. » → `L3-fr-en-12` : « Would you like some more? » | Faire varier l’objet dans I want…, puis introduire quantité et I’d like séparément. Préparer l’écoute de Would you like…? avant d’exiger une question produite. Ne pas confondre question avec do et question avec can. |
| L4 → L5 | `L4-fr-en-06` : « I work in a bank. » → `L5-fr-en-01` : « Yesterday I worked all day. » | Reprendre work puis worked avec le même vocabulaire avant d’introduire went/had et les questions avec did. Le nouveau repère temporel ne suffit pas à préparer toutes les formes irrégulières. |
| L6 → L7 | `L6-fr-en-04` : « I can't, but Sunday is fine. » → `L7-fr-en-01` : « I'm late because the train was late. » | Relier deux propositions déjà accessibles avec because ; ne pas introduire simultanément cause et nouveau passé. Garder comparaison, superlatif et used to en séquences distinctes. |
| L9 → L10 | `L9-fr-en-09` : « If I understand correctly, I need to take the next train? » → `L10-fr-en-03` : « If I get you right, you think we should move. » | Reprendre la vérification d’une consigne puis reformuler une opinion. Faire accepter une réponse équivalente et compréhensible, sans imposer le mot-à-mot du modèle. |

**Passage par L8.** En L8, partir d’une demande connue puis varier can/could selon le contexte ; travailler la condition séparément de la négociation et du lexique commercial.

## Espagnol pour francophones

| Pont | Appuis existants dans les contenus | Étapes à préparer |
|---|---|---|
| L1 → L3 | `L1-fr-es-03` : « Quiero un café. » → `L2-fr-es-01` : « Quisiera dos cafés, por favor. » → `L3-fr-es-06` : « ¿Tomamos un café? » | Conserver Quiero… et ses objets connus. Faire deux étapes pour quantité et Quisiera ; une invitation comme ¿Tomamos…? est un nouveau bloc et une nouvelle personne, pas un collage direct de quiero. |
| L4 → L5 | `L4-fr-es-06` : « Trabajo en un hospital. » → `L5-fr-es-01` : « Ayer trabajé mucho. » | Reprendre trabajar → trabajé avec un repère passé, puis introduire fui/estuve séparément. Ne pas demander immédiatement changement de temps, de sujet et de situation. |
| L6 → L7 | `L6-fr-es-05` : « No puedo, pero mañana sí. » → `L7-fr-es-01` : « Estudio español porque vivo en Valencia. » | Enrichir une réponse de refus/proposition avec une raison, en reprenant deux propositions connues. Comparaisons et anciennes habitudes doivent avoir chacune une préparation propre. |
| L9 → L10 | `L9-fr-es-09` : « Si he entendido bien, tengo que volver mañana, ¿no? » → `L10-fr-es-03` : « Si te entiendo bien, piensas que es mejor esperar. » | Passer de comprendre une consigne à reformuler une opinion. Réemployer les structures interrogatives sans ajouter en même temps tout le vocabulaire du logement ou du travail. |

**Passage par L8.** En L8, les demandes courantes peuvent être apprises tôt en blocs ; les conditions et les pronoms de « si me lo confirma… » demandent une progression distincte.

## Italien pour francophones

| Pont | Appuis existants dans les contenus | Étapes à préparer |
|---|---|---|
| L1 → L3 | `L1-fr-it-03` : « Vorrei un caffè. » → `L2-fr-it-01` : « Vorrei due caffè, per favore. » → `L3-fr-it-09` : « Ti va un caffè? » | Le pont Vorrei un… → Vorrei due… est déjà utile : garder d’abord le même objet. Ti va…? est une nouvelle invitation, à comprendre puis réutiliser ; ne pas la présenter comme permutation mot à mot de Vorrei. |
| L4 → L5 | `L4-fr-it-06` : « Lavoro in un ospedale. » → `L5-fr-it-01` : « Ieri ho lavorato tutto il giorno. » | Reprendre lavoro → ho lavorato avec les mêmes éléments. Introduire ensuite les formes avec essere et accords, puis deux actions ; ne pas mêler dès le premier essai tous les mécanismes du passé. |
| L6 → L7 | `L6-fr-it-06` : « Non posso, ma possiamo vederci domani. » → `L7-fr-it-01` : « Non vengo perché sono stanco. » | Réutiliser refus et disponibilité puis ajouter perché avec une cause connue. Le subjonctif dans Penso che sia… et la comparaison suivent chacun leur propre découverte. |
| L9 → L10 | `L9-fr-it-08` : « Se ho capito bene, devo tornare domani? » → `L10-fr-it-03` : « Se ho capito bene, pensi che sia troppo tardi. » | Garder Se ho capito bene comme appui et enrichir progressivement le contenu reformulé. Réutiliser une situation familière avant les arguments et nuances nouveaux. |

**Passage par L8.** En L8, préparer une demande simple et une réponse avant les négociations ; ne pas faire dépendre toute la réussite d’un nouveau vocabulaire administratif.

## Mandarin pour francophones

| Pont | Appuis existants dans les contenus | Étapes à préparer |
|---|---|---|
| L1 → L3 | `L1-fr-zh-03` : « 我要一杯咖啡。 » → `L2-fr-zh-01` : « 我想要两杯咖啡。 » → `L3-fr-zh-09` : « 你是学生吗？ » | Réutiliser d’abord 我要 avec eau/thé ; le compteur 杯, le nombre 两 et 想要 ne doivent pas arriver ensemble. Pour les questions en 吗, préparer la question et la réponse adaptée au verbe ; éviter un oui/non universel. |
| L4 → L5 | `L4-fr-zh-03` : « 晚上我做饭。 » → `L5-fr-zh-01` : « 昨天我看电影了。 » | Reprendre une action déjà connue avec 昨天, puis travailler 了 dans les exemples concernés. Ne pas le présenter comme un temps passé universel ; distinguer aussi la négation 没 et la chronologie. |
| L6 → L7 | `L6-fr-zh-05` : « 我不行，不过星期天可以。 » → `L7-fr-zh-02` : « 我喜欢这里，因为很安静。 » | Reprendre invitation/réponse, puis relier deux propositions courtes par une cause. Comparaison en 比, opinion et changement d’habitude ne doivent pas devenir une seule nouvelle tâche. |
| L9 → L10 | `L9-fr-zh-08` : « 如果我没理解错，要先去三号窗口？ » → `L10-fr-zh-03` : « 如果我理解得对，你觉得我们应该等一等？ » | Élargir une vérification concrète vers la reformulation d’une opinion. Stabiliser les blocs d’aide à la compréhension avant d’ajouter des cadres discursifs plus longs. |

**Passage par L8.** En L8, une demande polie simple existe déjà ; construire ensuite l’alternative puis la condition. L’écriture et les tons restent accompagnés par les aides de lecture et l’audio, sans devenir un examen de caractères.

## Japonais pour francophones

| Pont | Appuis existants dans les contenus | Étapes à préparer |
|---|---|---|
| L1 → L3 | `L1-fr-ja-03` : « コーヒーをください。 » → `L2-fr-ja-01` : « コーヒーを二つください。 » → `L3-fr-ja-12` : « お茶はいかがですか。 » | Conserver コーヒーをください puis découvrir une quantité. L’offre お茶はいかがですか est un autre rôle et un autre bloc : la préparer à l’écoute avant d’attendre une réponse. Ne pas traduire un gabarit français en conservant l’ordre français. |
| L4 → L5 | `L4-fr-ja-11` : « 休みの日は映画を見ます。 » → `L5-fr-ja-01` : « 昨日映画を見ました。 » | Le lien 映画を見ます → 映画を見ました permet une variation claire avec lexique conservé. Entraîner ensuite les autres verbes, adjectifs et négations séparément au lieu de déduire toutes les formes d’un exemple. |
| L6 → L7 | `L6-fr-ja-06` : « ちょっと無理ですが、日曜日なら大丈夫です。 » → `L7-fr-ja-01` : « 雨ですから、今日は家にいます。 » | Commencer par une proposition et un refus compris, puis ajouter une raison connue. Les connecteurs から/ので ne deviennent pas automatiquement interchangeables dans toute phrase ; faire contrôler les exemples complets. |
| L9 → L10 | `L9-fr-ja-07` : « 明日は来なくてもいいということですか。 » → `L10-fr-ja-03` : « つまり、値段が高すぎるとお考えなんですね。 » | Reprendre une vérification avant le cadre plus long et plus formel お考えなんですね. Le registre et l’honorifique sont une difficulté supplémentaire ; ne pas les confondre avec la seule longueur. |

**Passage par L8.** En L8, séparer condition, changement de réservation et demande avec いただけますか. Les particules et formes conjuguées font partie des blocs validés ; préserver lecture, phonétique adaptée et audio.

## Coréen pour francophones

| Pont | Appuis existants dans les contenus | Étapes à préparer |
|---|---|---|
| L1 → L3 | `L1-fr-ko-03` : « 커피 주세요. » → `L2-fr-ko-01` : « 커피 두 잔 주세요. » → `L3-fr-ko-05` : « 같이 먹어요? » | Le pont 커피 주세요 → 커피 두 잔 주세요 est productif si le compteur et le nombre sont préparés. Pour 같이 먹어요?, préparer l’action et son intonation de proposition ; ne pas laisser le français dicter les sujets exprimés. |
| L4 → L5 | `L4-fr-ko-03` : « 저녁에 요리해요. » → `L5-fr-ko-08` : « 비빔밥을 먹었어요. » | Le passage au passé devrait d’abord reprendre exactement le verbe et l’objet du quotidien ; les modèles actuels changent souvent les deux. Introduire ensuite les différentes finales et la négation, avec phrases complètes contrôlées. |
| L6 → L7 | `L6-fr-ko-05` : « 미안해요, 토요일에는 못 가요. » → `L7-fr-ko-01` : « 피곤해서 집에 있었어요. » | Réemployer une réponse de refus puis une cause connue avant de relier les propositions. Cause en -아서/어서, explication en -거든요 et comparaison ne sont pas une seule famille interchangeable. |
| L9 → L10 | `L9-fr-ko-09` : « 제가 제대로 이해했다면, 내일 다시 와야 해요? » → `L10-fr-ko-03` : « 제가 이해하기로는, 재택근무가 더 좋다고 생각하시는 거죠? » | Réutiliser une vérification courte puis développer l’opinion rapportée. Préparer les finales et l’honorifique avant une longue reformulation ; viser une réponse adaptée, pas la récitation. |

**Passage par L8.** En L8, séparer la demande honorifique, la condition et les démarches. Les particules et les formes de liaison doivent être livrées dans des blocs corrects ; l’assemblage ne demande pas au débutant de deviner leurs variantes.

## Règles conservées sur ordinateur, site mobile et application

- Même ordre d’apprentissage et mêmes prérequis ; présentation adaptée au support.
- Phonétique dans la langue maternelle conservée comme aide disponible ; lecture standard et audio restent complémentaires.
- Les briques sont des groupes de sens et des formes validées, pas nécessairement des mots séparés.
- Toute nouvelle combinaison est vérifiée dans la phrase complète : accords, déterminants, particules, pronoms, conjugaison et enchaînements.
- La compréhension de l’interlocuteur précède le dialogue masqué ; les formes connues reviennent dans une autre situation puis après une interruption.
- Conserver la réserve actuelle ; améliorer l’ordre, les liens et les étapes intermédiaires. Le document ne demande aucune modification technique immédiate.

## Essai à valider

Claude peut préparer une petite chaîne exemplaire par langue à partir de ces appuis. Kartech examine la maquette, puis les essais sur les trois supports précèdent toute éventuelle publication. Les contenus zh/ja/ko et le français pour sinophones gardent leur statut de relecture native requise ; la cohérence pédagogique documentaire ne vaut pas validation linguistique exhaustive.
