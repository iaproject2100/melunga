# Audit pédagogique des contenus « Mes phrases » — L1 à L10

20 octobre 2026. Revue locale des 70 fichiers structurés et de la matrice du dépôt au commit `49dca94`. Aucune donnée, aucun écran, aucune branche distante modifiés. Ce document propose des essais avec Claude ; Kartech décide des changements et de toute publication.

## Périmètre réel

Les sept couples livrés sont fr→es, fr→en, fr→it, fr→zh, fr→ja, fr→ko, zh→fr. La revue porte sur la structure des dix niveaux de chaque couple, les modèles et des variantes ciblées, et la progression des 210 dialogues (contenu étudié ou traduction de contrôle). Elle ne certifie pas chaque traduction, chaque phonétique ou le naturel natif de chaque réplique. Les champs de validation technique ne prouvent pas une progression pédagogique.

Les fichiers fournissent 841 modèles, 3 364 variantes et 210 dialogues. Leur richesse est à conserver. L’amélioration prioritaire consiste à organiser l’acquisition et le réemploi, plutôt qu’à supprimer les phrases ou à augmenter encore le volume.

## Diagnostic commun

Le parcours déclaré — découvrir, remplacer, rappeler, converser — est cohérent avec la méthode de Kartech. Les phrases complètes font autorité, ce qui protège contre des collages grammaticaux incorrects. Mais les données décrivent surtout des modèles parallèles et des scènes ; elles ne décrivent pas encore les petites étapes nécessaires pour passer d’une structure à la suivante.

La question centrale n’est pas seulement « cette phrase est-elle utile ? », mais « quelles briques permettent déjà à l’apprenant de la comprendre et de la recréer ? ». Un dialogue peut introduire des formules nouvelles en compréhension. Elles doivent alors être préparées comme telles, pas supposées acquises parce qu’un modèle voisin figure dans `reuses`.

## Revue des dix niveaux

| Niveau | Réussite actuelle | Difficulté constatée | Amélioration proposée en conservant le contenu |
|---|---|---|---|
| L1 | Besoin, identité, commande, lieu et prix : fonctions très utiles ; dépannage présent dès le début | Onze familles de structures et plusieurs registres simultanés ; les échanges reçus ajoutent salutations, directions, nombres et formules d’accueil | Créer une entrée courte écouter→comprendre→imiter ; une famille puis une transformation ; distinguer réserve L1 et première séance |
| L2 | Bons ponts quantité : `Vorrei un caffè`→`Vorrei due caffè`, `커피 주세요`→`커피 두 잔 주세요` | Quantité, compteur, horaire, préférence, taille et localisation parfois regroupés ; deux nouveautés peuvent se cacher dans une seule variante | Une séquence quantité sur objet familier ; une autre horaire ; réponse entendue préparée séparément |
| L3 | Questions, demandes de répétition et relances ouvrent une vraie conversation | Ouvrir un compte, expliquer son métier ou demander une dose de médicament ajoutent un vocabulaire nouveau pendant l’apprentissage du mécanisme interrogatif | Transformer d’abord des phrases L1–L2 connues en questions ; ensuite seulement changer de domaine |
| L4 | Verbes du quotidien, maison, famille, emploi et fréquence se combinent bien | Enrichissement lexical important et personnes grammaticales multiples : ma sœur/mes enfants/leur âge/leur métier | Construire une journée personnelle avec les mêmes verbes ; enrichir un paramètre à la fois ; proposer une identité personnalisable plutôt qu’un personnage à réciter |
| L5 | Passé situé par hier/week-end et mini-récits ; réactions donnent de la vie aux échanges | Mélange de plusieurs formes de passé, négation, passé interrogatif, récit à plusieurs actions ; formules de nouvelles très simples parfois introduites seulement ici | Réutiliser un verbe L4 au passé, puis le nier, puis poser la question, puis combiner deux actions ; rencontrer « ça va ? » plus tôt comme bloc |
| L6 | Invitations, refus avec alternative et confirmation sont des objectifs efficaces et concrets | Plusieurs moyens de futur/intention et d’invitation concurrents, parfois nouveaux à la fois | Un scénario connu en trois passages : proposer, refuser, déplacer ; futur/intention enrichis progressivement, sans imposer une traduction mot à mot |
| L7 | Comparer, expliquer un choix et opposer avant/maintenant prépare l’autonomie | Cause, opinion, comparaison, superlatif et anciennes habitudes sont cinq opérations différentes | Séparer les micro-séquences ; comparer les mêmes objets puis justifier avec une proposition déjà maîtrisée |
| L8 | Demandes, délais, panne et négociation réutilisent besoins/projets/causes | Registre poli, conditions, pronoms et vocabulaire administratif changent ensemble ; le marchandage n’est pas approprié dans toutes les situations | Formule polie simple accessible tôt ; travailler ensuite la condition sur les mêmes mots ; contextualiser les usages culturels |
| L9 | Réparer un malentendu et trouver une alternative développe une vraie compétence | Les modèles mêlent des phrases de secours très simples et des hypothèses/reformulations complexes ; la santé de base apparaît tard | Conserver L9 pour incidents à plusieurs étapes ; proposer plus tôt « j’ai mal à… », « répétez » et « je ne comprends pas » comme blocs ; ne pas confondre utilité précoce et grammaire entièrement analysée |
| L10 | Mélange récit, choix, objection, clarification : meilleure intégration des acquis ; plusieurs thèmes réapparaissent | Dialogues encore entièrement écrits, parfois plus formels que la vie courante ; réciter dix répliques ne prouve pas qu’on converse | Garder les dialogues modèles, puis proposer objectif et choix de réponses plausibles ; situation nouvelle avec mots connus, sans ajouter obligatoirement plus de lexique abstrait |

## Points par langue et exemples traçables

### Espagnol

- `L1-fr-es-06` : `Voy al trabajo / a casa / al mercado / al hotel` est une famille utile. L’alternance `a/al` mérite une aide sur la phrase complète ; il ne faut pas laisser croire que tout nom s’insère après un `Voy a` invariant.
- `L1-fr-es-d1` : `¿Qué desea?`, `¿Con leche?`, `Dos euros` ne découlent pas des seules variantes de commande/prix. Préparer ces réponses en écoute avant le dialogue masqué.
- `L2-fr-es-01` : passer à `Quisiera dos cafés` change à la fois la quantité et `Quiero` en `Quisiera`. Les deux sont utiles ; commencer par la quantité avec une formulation connue, puis présenter la nuance polie dans une autre séquence.
- `L3-fr-es-06` puis `L6-fr-es-d1` : café proposé → sortie cinéma déplacée au dimanche constitue une bonne reprise fonctionnelle, à rendre explicite.
- `L7-fr-es-d3` réemploie le quotidien L4, la cause, la comparaison et l’opposition avant/maintenant : bon dialogue d’intégration, à garder après les séquences séparées.

### Anglais

- `L1-fr-en-06` : `I'm going to work / I'm going home / I'm going to the market` contient une exception de construction (`home` sans `to`). La donnée complète est juste ; expliciter le bloc plutôt qu’autoriser un collage libre.
- `L1-fr-en-d3` demande de comprendre `Are you on holiday?`, puis de répondre `Yes, I really like the city`. Le lien de sens est plausible, mais identité, question et intensité ne sont pas la même opération.
- `L3-fr-en-10` propose `Nice to meet you, I'm Mary, from the Paris office` ou `Paul's colleague` ; formule d’accueil, lieu professionnel et possession sont regroupés dans un morceau long. Garder ces variantes en enrichissement après un nom simple.
- `L3-fr-en-11` (`I'd like to open an account/register…`) est utile mais ne doit pas être un prérequis pour réussir les premières questions sur manger/boire.
- `L9-fr-en-d1` et `L10-fr-en-d2` offrent de vrais problèmes à résoudre : train annulé/alternative, projet limité par les vacances. Bons supports de transfert après préparation lexicale.

### Italien

- Bon réemploi L1→L2 avec `Vorrei un caffè`→`Vorrei due caffè`. Le débutant peut pratiquer la quantité sans changer de verbe.
- `L1-fr-it-06` : `Vado al lavoro/a casa/al mercato/in albergo` regroupe plusieurs prépositions ; conserver les phrases mais guider par lieu et formulation connue.
- `L2-fr-it-d1` ajoute `cornetto`, `semplice/alla crema`, prix décimal et `Qualcos'altro?`. Intéressant pour une scène réelle, mais première version plus courte ou préparation de ces blocs nécessaire.
- `L3-fr-it-d1` introduit `Possiamo darci del tu?` : bonne information de registre et de culture, à entendre comme formule de contexte ; ne pas en demander immédiatement l’analyse et la production autonome.
- `L3-fr-it-d3` utilise déjà le mal de tête et des consignes de prise ; les modèles `Ho mal di testa` n’arrivent qu’en L9. Ce décalage prouve qu’il faut référencer le lexique reçu et pas seulement les modèles textuellement réutilisés.

### Chinois

- `L1-fr-zh-01` passe de `我是学生` à `我是来度假的` : la seconde implique un bloc plus complexe que profession/nationalité. La garder en enrichissement, sans en faire le premier rappel obligatoire du débutant absolu.
- `L1-fr-zh-03` cumule `一杯咖啡 / 水 / 一张票 / 一个三明治` : quatre objets et trois compteurs. Construire d’abord eau/thé sans compteur, puis une unité familière, avant 张 et 个 dans d’autres scènes.
- `L1-fr-zh-d2` : `我需要一张去上海的票` ajoute le groupe `去上海的票` par rapport au modèle de billet. Préparer ce bloc ou simplifier l’étape d’essai ; la réserve peut rester intacte.
- `L6-fr-zh-02` comporte une note utile : 明天 porte souvent la référence future sans 会. À préserver : ne pas enseigner un faux auxiliaire universel du futur.
- `L7-fr-zh-d3` relie appartement, comparaison, cause et déplacements quotidiens ; bonne intégration, à préparer après séparation de ces opérations.

### Japonais

- Les modèles L1 en `をください`, `をお願いします`, `はどこですか` sont des briques utiles ; les deux demandes proches peuvent être espacées pour éviter une surcharge de synonymes.
- `L1-fr-ja-07` indique explicitement que faim/soif/froid/chaud sont des phrases entières et non le calque de « avoir ». Bon choix à conserver.
- `L1-fr-ja-d2` (`大阪までの切符が必要です`, `切符一枚、千円です`) ajoute destination, compteur et prix. L’oral reçu demande sa propre préparation.
- `L2-fr-ja-d3` utilise le refus indirect `明日はちょっと…`. L’apprenant doit comprendre qu’il s’agit d’un refus dans ce contexte avant d’essayer de répondre. Apprendre seulement « demain/un peu » mot à mot ne suffit pas.
- `L3-fr-ja-d2` et les dialogues avancés distinguent demande polie, offre du commerçant et réponse ; bon contexte de registre. Éviter de les fondre dans une règle unique de « tu/vous ».
- Les formes en て/た, la nominalisation et les demandes élaborées gagnent à être introduites sur des verbes déjà connus ; ne pas faire dépendre la réussite orale de la lecture autonome des kanji.

### Coréen

- `L1-fr-ko-01` regroupe `저는 학생이에요` et `저는 파리에서 왔어요`. La traduction « je suis de Paris » masque une structure d’origine exprimée par « venir ». Faire une étape distincte ; la présence du même début 저는 ne suffit pas à prouver une substitution de difficulté égale.
- `L1-fr-ko-08` passe d’objets (`커피를`, `음악을`) à `걷는 걸` : aimer marcher demande une nominalisation. Garder cette variante, mais après une transition explicite.
- `L1-fr-ko-07` signale correctement que les sensations sont des phrases complètes.
- `L2-fr-ko-d2` associe compteurs de billets, horaires, minutes et place côté fenêtre. Préparer le choix reçu et les nombres avant l’échange.
- `L4-fr-ko-d1` distingue les termes de parenté ; `오빠` est lié au locuteur. Ne pas proposer cette variante comme « grand frère » universel sans contexte de personnage.
- `L8-fr-ko-d3` : congé/visa/réunion déplacée combine bien les acquis ; le vocabulaire professionnel et les honorifiques restent à vérifier par un natif.

### Français pour sinophones

- `L1-zh-fr-03` et `-06` font voir des alternances réelles : `un café/de l’eau/un billet` et `au travail/à la gare/au marché/à l’hôtel`. Garder les phrases complètes et apprendre les petits groupes avec le nom ; ne pas enseigner une substitution de mot isolé universelle.
- `L1-zh-fr-d3` inclut `Je suis chinoise` et `Vous êtes en vacances ?` ; personnaliser le rôle et la réponse évite de mémoriser une biographie qui n’est pas la sienne.
- `L3-zh-fr-03/-04` distingue tu/vous et `L3-zh-fr-d1` contextualise le vouvoiement au travail. Bon point, à préserver sans introduire toutes les variantes de registre dans la même première séquence.
- `L5-zh-fr-08` (« je n’ai pas dormi ») et les autres unités de passé demandent des reprises de verbes déjà familiers. Les aides phonétiques chinoises et l’audio sont particulièrement importants pour auxiliaires, liaisons et groupes de sons ; cet audit ne certifie pas leur justesse.
- `L10-zh-fr-d3` donne un bon objectif de conversation : proposer un essai de télétravail après objection et clarification. À prolonger par un choix personnel, pas seulement un dialogue à réciter.

## Priorités d’essai proposées

1. **Entrée L1 courte et préparée**, chinois en priorité, puis même principe testé en espagnol. La réserve existante reste disponible.
2. **Préparer les réponses reçues**, pas seulement la phrase produite par l’apprenant : choix, refus, direction, prix, demande de précision.
3. **Marquer dans un document les briques connues et la nouveauté** de chaque séquence. Un gabarit identique peut cacher une nominalisation, un nouveau temps ou un groupe long.
4. **Relier les niveaux par des reprises précises** : même verbe, même objet, transformation ; puis changer de contexte. Une liste générale « réutilise L1/L2 » est insuffisante pour cela.
5. **Distinguer trois résultats** : reconnaître, répéter, produire une combinaison nouvelle. Le dernier modèle consulté ou un clic « Je connais » ne mesure pas tous les trois.
6. **Ajouter les révisions et le transfert au parcours**, sans supprimer les aides phonétiques et sans masquer une réponse jamais découverte.
7. **Adapter aux trois supports** : mêmes objectifs et contenus, présentation adaptée ordinateur/site mobile/application ; ne pas évaluer une difficulté de manipulation comme un manque de connaissance linguistique.

## Ce que Claude peut préparer sans toucher à l’application

Une table de séquençage par niveau : objectif → briques reprises avec références → nouveauté → questions à comprendre → variantes correctes → phrase nouvelle attendue → rappel ultérieur. Commencer par le pilote L1–L3, puis réviser les autres niveaux selon les résultats observés. Toute correction linguistique incertaine doit rester signalée pour relecture native. Aucune affirmation de couverture « 80 % de la conversation », d’équivalence CECRL ou d’efficacité démontrée sans étude dédiée.

## Grille de décision centrée sur la progression et la difficulté

Suite à la précision de Kartech : les remarques linguistiques précédentes servent uniquement à expliquer une difficulté d’apprentissage. Elles ne constituent pas un nouvel objectif d’audit linguistique exhaustif.

| Niveau | Acquis à réutiliser | Une opération principale à exercer | Réemploi créé par l’apprenant |
|---|---|---|---|
| L1 | Quelques objets et blocs entendus dans la même séquence | Remplacer un objet familier dans une demande | Choisir sa boisson et la demander sans recopier une phrase affichée |
| L2 | Même demande et mêmes objets | Préciser une quantité, puis séparément un lieu ou un moment | Commander une quantité différente avec une formulation déjà connue |
| L3 | Demandes/besoins/choix L1–L2 | Transformer pour demander à l’autre | Poser une question nouvelle avec des mots connus et comprendre la réponse |
| L4 | Actions, lieux et personnes déjà rencontrés | Compléter une phrase du quotidien | Décrire sa propre journée, différente du modèle |
| L5 | Une action habituelle L4 | La situer dans un événement passé | Raconter un événement personnel en une phrase, puis en deux |
| L6 | Action + moment + question connus | Proposer et ajuster un projet | Inviter à une activité différente et proposer un autre horaire après un refus |
| L7 | Deux propositions simples connues | Les relier par une raison ; comparaison dans une autre séquence | Justifier un choix personnel avec deux idées déjà accessibles |
| L8 | Demande polie simple et choix connus | Adapter la demande sous une condition | Négocier un changement avec sa propre condition compréhensible |
| L9 | Problème simple et question de secours connus | Clarifier puis chercher une alternative | Résoudre une variante d’incident que le dialogue modèle ne donne pas mot pour mot |
| L10 | Répertoire des niveaux précédents | Choisir et combiner les ressources sans parcours imposé | Tenir un échange sur une situation nouvelle avec aide disponible, plusieurs réponses acceptables |

Cette grille n’impose pas la même grammaire à toutes les langues. Une étape apparente peut en nécessiter plusieurs : changer le sujet en espagnol modifie la forme verbale ; changer un objet en français peut modifier le déterminant ; exprimer « aimer une action » en coréen demande une construction spécifique. La difficulté doit être comptée du point de vue de l’apprenant, pas par nombre de cases remplies dans le générateur.

**Vrai L1 proposé :** premier objectif réduit à une interaction réalisable, accompagnée et réutilisable, sans exiger dès la première séance nom/origine/besoin/goût/direction/prix/compteurs. Les autres contenus L1 restent dans la réserve et deviennent accessibles par petites séquences.
