# Melunga — trois fils quotidiens de L1 à L10

Proposition locale pour Kartech et Claude, 20 octobre 2026. Aucun contenu applicatif modifié, rien publié. Ce document complète les dix fiches ; il ne remplace pas leur revue ni la validation de Kartech.

Les phrases françaises ci-dessous sont **illustratives** : elles expriment l’intention et ne sont pas des traductions finales à injecter dans les sept langues. Les références sont des modèles existants de la réserve, à réutiliser lorsque la situation correspond. Un modèle d’un autre thème peut fournir une opération, mais ne valide pas à lui seul une nouvelle phrase. Claude doit vérifier les ponts, les formulations, la phonétique pour le lecteur et l’audio avant un essai.

## Règle commune des trois fils

La **phrase principale est l’unité de la leçon**. On l’entend et on en comprend le sens, on peut la répéter, puis on choisit un morceau préparé pour construire sa propre variante. Une leçon peut comporter plusieurs petits passages ; elle n’exige pas de tout réussir au premier affichage.

La phrase originale, l’aide phonétique adaptée à la langue maternelle, le sens et la réécoute restent accessibles. La phonétique n’est pas retirée automatiquement pour « faire plus difficile ». Les essais peuvent réduire l’aide à l’initiative de l’apprenant, puis distinguer ce qui est compris ou produit avec et sans modèle.

Les mots et les réponses reçues sont préparés avant la transformation visée. On ne demande pas à la fois de découvrir un verbe, de changer de temps, de comprendre une consigne et de lire une écriture inconnue. Aucun test écrit n’est obligatoire pour avancer dans ces parcours oraux.

Les mêmes objectifs s’appliquent sur ordinateur, site mobile et application. Un clic, un toucher ou un glissement ne change pas la compétence visée.

## Fil 1 — Boire, manger et partager un repas

| Niveau | Intention et phrase française illustrative | Structure antérieure réutilisée | Transformation principale | Difficulté à préparer avant l’essai |
|---|---|---|---|---|
| **L1** | Obtenir une boisson : « Un thé, s’il vous plaît. » puis choisir de l’eau | Première structure découverte ; aucun acquis supposé | Remplacer la boisson dans une demande stable | Eau/thé découverts séparément ; comprendre le choix proposé ; demande polie selon le contexte |
| **L2** | Préciser pour deux : « Deux thés, s’il vous plaît. » | Même demande et même boisson L1 | Changer la quantité | Un/deux, pluriel ou compteur dans la langue ; ne pas ajouter simultanément une nouvelle forme polie |
| **L3** | S’intéresser à l’autre : « Tu veux du thé ? » | Intention de boisson et choix L1–L2 | Transformer pour poser une question | Personne et forme interrogative préparées successivement ; réponses naturelles à cette question, pas un oui/non universel |
| **L4** | Parler de son habitude : « Le matin, je bois du thé. » | Boire et boisson, déjà compris dans les séquences précédentes | Ajouter le moment habituel | Boire comme action si L1 ne travaillait qu’une demande ; matin/soir ; distinguer une habitude d’une commande |
| **L5** | Raconter : « Hier, j’ai bu du thé chez moi. » | Action, boisson et lieu familiers L4 | Situer un événement passé | Forme passée/aspect de boire propre à la langue ; hier ; conserver le reste de la phrase familier |
| **L6** | Proposer un repas : « On mange ensemble demain ? » | Manger découvert dans une autre leçon L4, moment L2, question L3 | Transformer en invitation | Demain et ensemble ; une formule d’invitation ; accepter/refuser préparés en oral reçu |
| **L7** | Expliquer un choix : « Je préfère manger ici parce que c’est près. » | Choix et lieu connus ; deux propositions comprises séparément | Relier le choix à sa raison | Préférence et proximité déjà disponibles ; introduire la liaison de cause sans nouveau temps ou adjectif |
| **L8** | Poser une condition : « Si on peut venir à huit heures, je réserve. » | Heure, possibilité et réservation préalablement préparées | Lier condition et conséquence | Les deux propositions sont d’abord découvertes séparément ; condition réelle dans la langue, pas traduction mécanique de « si » |
| **L9** | Corriger une réservation : « Si j’ai bien compris, c’est à huit heures, pas à sept heures ? » | Réservation et horaires L6–L8 | Reformuler pour faire confirmer | Comprendre confirmation et correction ; le problème n’est pas ajouté avec tout un lexique de restaurant inconnu |
| **L10** | **Tâche ouverte :** organiser un repas avec des préférences et disponibilités différentes ; expliquer son choix, réagir à un refus et confirmer l’accord | Questions, habitudes, passé utile, invitation, raison, condition et clarification L1–L9 | Choisir la ressource selon ce que dit l’autre | Présenter les contraintes au fur et à mesure ; plusieurs issues possibles : autre lieu, autre jour, accord partiel ou report |

**Points d’appui existants :**

- Entrée demande L1 : `L1-fr-es-09` et `L1-fr-zh-09` ; en chinois, éviter de découvrir demande complète + tasse + boisson inconnue dans le même passage.
- Quantité L2 : `L2-fr-es-01` et `L2-fr-zh-01` ; séparer leur nouvelle formulation de demande et la quantité si nécessaire.
- Invitation L3 puis enrichissement L6 : `L3-fr-es-06`, `L3-fr-zh-07`, `L6-fr-es-02` ; la même fonction peut être rencontrée tôt en bloc puis construite plus librement.
- Habitude L4 et choix motivé L7 : `L4-fr-zh-02`, `L7-fr-es-04`, `L7-fr-zh-05`. Le modèle chinois L7 porte sur le métro : il fournit un mécanisme de préférence + raison, pas une phrase de restaurant déjà validée.

**Ponts à préparer :** questions simples sur la boisson connue ; action boire avant sa transformation passée ; nouvelle invitation à un repas si le modèle source parle du cinéma ; réservation conditionnelle et confirmation d’heure. Vérifier si des cartes existantes permettent de préparer ces ponts avant de rédiger de nouvelles phrases.

**Essai de transfert :** changer la boisson en L1, le moment en L4, le repas raconté en L5, puis les contraintes de la sortie en L10. La réussite n’est pas de réciter dix phrases de plus en plus longues.

## Fil 2 — Se déplacer et arriver à destination

| Niveau | Intention et phrase française illustrative | Structure antérieure réutilisée | Transformation principale | Difficulté à préparer avant l’essai |
|---|---|---|---|---|
| **L1** | Dire sa destination : « Je vais au marché. » puis choisir la gare | Première structure de déplacement découverte | Remplacer le lieu connu | Marché/gare ; préposition ou particule avec le lieu ; ne pas assimiler déplacement et futur d’une action |
| **L2** | Situer le départ : « Le train part à neuf heures. » | Lieux et déplacement L1 ; départ découvert comme action | Ajouter une heure à une phrase connue | Comprendre l’heure avant de la produire ; nouveau verbe de départ préparé séparément |
| **L3** | Obtenir une information : « À quelle heure part le train ? » | Phrase de départ et heure L2 | Transformer l’information en question | Question reçue et réponses horaires ; ne pas ajouter un changement de ville ou de transport au premier essai |
| **L4** | Décrire son trajet habituel : « Je vais au travail en métro tous les jours. » | Déplacement + lieu et moyen de transport déjà découverts | Ajouter une fréquence | Moyen de transport appris avant fréquence ; matin/tous les jours/souvent ne sont pas une liste à apprendre ensemble |
| **L5** | Raconter un trajet : « Hier, je suis allé au marché. » | Destination L1 et déplacement L4 | Situer le déplacement dans le passé | Forme du verbe ou repère/aspect propre à la langue ; même lieu au premier passage |
| **L6** | Préparer le trajet ensemble : « On prend le métro demain ? » | Trajet connu, moment L2, questions L3 | Faire une proposition à l’autre | Une invitation de déplacement ; comprendre un autre moyen proposé ; choix de métro/bus préparé |
| **L7** | Justifier son moyen de transport : « Je préfère le métro parce que c’est plus rapide. » | Préférence connue, deux moyens préparés et descriptif rapide | Relier le choix à une raison | Apprendre la comparaison dans une séquence distincte ; ne pas introduire simultanément le superlatif ou plusieurs adjectifs |
| **L8** | Adapter le plan : « Si le train est complet, on prend le bus. » | Transport, choix et alternative L6–L7 | Condition + solution de remplacement | Comprendre complet/disponible avant de les utiliser ; deux propositions préparées ; pas de nouveau jargon de billet |
| **L9** | Faire confirmer une solution : « Donc je peux prendre le prochain train avec ce billet ? » | Demande de possibilité L8 et horaires connus | Vérifier une information reformulée | Le billet, prochain et validité doivent être compris ; prévoir confirmation et réponse négative explicite |
| **L10** | **Tâche ouverte :** rejoindre quelqu’un malgré un départ annulé, un budget limité ou une destination modifiée ; demander, comparer, informer et convenir d’une solution | Répertoire des neuf niveaux : destination, horaires, récit bref, alternative, raison et clarification | Adapter ses réponses à un imprévu non annoncé | Une contrainte nouvelle à la fois au premier essai ; plusieurs solutions acceptables, y compris reporter le déplacement |

**Points d’appui existants :**

- Destination L1 : `L1-fr-es-06` et `L1-fr-zh-06` ; les lieux et leurs constructions restent propres à chaque langue.
- Horaire L2 : `L2-fr-es-08`, `L2-fr-zh-06` ; la question peut être d’abord entendue comme bloc, avant d’en développer la construction au L3.
- Passé L5 et trajet proposé L6 : `L5-fr-es-02`, `L5-fr-zh-02`, `L6-fr-zh-10`.
- Choix L7 : `L7-fr-es-02` et `L7-fr-zh-05` ; comparaison et justification sont préparées séparément avant combinaison.
- Incident L9 : `L9-fr-es-07`, `L9-fr-zh-07`, `L9-fr-zh-08` ; le prochain trajet ne doit pas être deviné sans comprendre l’information reçue.

**Ponts à préparer :** affirmer le départ avant de le questionner ; relier un trajet connu à une fréquence ; moyen complet/annulé et alternative ; validité du billet. Les répliques techniques des dialogues existants peuvent rester en enrichissement pendant que l’on prépare un premier échange plus court.

**Essai de transfert :** conserver le mécanisme et changer la destination, le moment ou l’autre personne. En L10, varier la réponse de l’agent ; ne pas imposer un dialogue unique à apprendre.

## Fil 3 — Se rencontrer et gérer un rendez-vous

| Niveau | Intention et phrase française illustrative | Structure antérieure réutilisée | Transformation principale | Difficulté à préparer avant l’essai |
|---|---|---|---|---|
| **L1** | Se présenter à la rencontre : « Bonjour, je m’appelle… » | Salutation et présentation découvertes comme blocs | Remplacer le nom par le sien | Comprendre la réponse de présentation ; ne pas exiger origine, métier, âge et raison de visite à la fois |
| **L2** | Préciser quand se voir : « On se voit à huit heures. » | Rencontre L1 ; phrase de rencontre et heure découvertes | Changer le moment connu | Distinguer huit heures/demain ; travailler un repère à la fois ; comprendre une confirmation simple |
| **L3** | Demander le moment : « À quelle heure on se voit ? » | Rencontre et horaire L2 | Transformer pour demander une information | Le mécanisme de question et la réponse attendue ; les relances « et où ? » arrivent après un premier échange compris |
| **L4** | Parler d’une habitude : « Le samedi, je vois ma famille. » | Rencontrer/voir et personnes déjà introduites | Ajouter la fréquence habituelle | Verbe naturel selon le contexte et liens familiaux ; ne pas supposer qu’un nom de personne et « ma famille » sont interchangeables grammaticalement |
| **L5** | Raconter une rencontre : « Hier, j’ai vu un ami. » | Rencontre familière, personne et moment L4 | Situer l’événement dans le passé | Forme passée de voir/rencontrer avant autre verbe ; répondre à où/avec qui avec des mots connus |
| **L6** | Déplacer un rendez-vous : « Je ne peux pas samedi, mais dimanche, oui. » | Horaire L2, question L3, choix d’alternative déjà préparé | Refus + proposition qui maintient l’échange | Négation et disponibilité préparées séparément ; ne pas multiplier les formules concurrentes d’excuse |
| **L7** | Expliquer une préférence : « Je préfère dimanche parce que je travaille samedi. » | Jour, travail et préférence connus ; deux propositions simples | Relier préférence et raison | Découvrir travail/disponibilité avant de les combiner ; rester dans un registre familier ou poli cohérent |
| **L8** | Accepter sous condition : « D’accord, si on se voit près de la gare. » | Accord, lieu et rencontre connus | Restreindre l’accord par une condition | Faire comprendre que l’accord dépend du lieu ; l’autre peut accepter ou proposer un autre lieu |
| **L9** | Réparer le malentendu : « J’avais compris neuf heures ; vous dites dix heures ? » | Rencontre, horaire et récit d’une information précédente | Contraster ce qui était compris et ce qui est confirmé | La formulation française peut ajouter une difficulté temporelle ; chaque langue cherche le moyen naturel le plus accessible, sans imposer le plus-que-parfait français |
| **L10** | **Tâche ouverte :** convenir d’un rendez-vous avec deux disponibilités différentes, rappeler un engagement, expliquer une contrainte, vérifier l’accord et conclure | Présentation, horaires, habitudes, récit, alternatives, raisons, condition et clarification L1–L9 | Conduire l’échange selon les réponses reçues | Préparer les intentions et mots de contraintes ; l’accord final peut être un autre moment, une autre modalité ou un report |

**Points d’appui existants :**

- Présentation L1 puis moment L2 : `L1-fr-es-02`, `L1-fr-zh-02`, `L2-fr-es-04` ; d’autres variantes horaires chinoises sont disponibles en L2.
- Rencontre habituelle et récit : `L4-fr-es-12`, `L4-fr-zh-10`, `L5-fr-zh-10`. Certaines variantes de ces unités ne portent pas toutes sur une rencontre : sélectionner la phrase pertinente, pas l’unité entière par défaut.
- Déplacement du rendez-vous L6 : `L6-fr-es-05`, `L6-fr-zh-05`, `L6-fr-es-07` ; dernier modèle utile pour confirmer l’issue.
- Possibilité de changer l’heure et clarification : `L8-fr-zh-05`, `L9-fr-es-09`, `L9-fr-zh-08`. Préparer une formulation de confirmation cohérente avec le rendez-vous ; les modèles sources ne sont pas tous dans ce thème.
- Conversation L10 : `L10-fr-es-03`, `L10-fr-zh-03`, `L10-fr-zh-04` pour reformuler et résumer une décision réelle ; ne pas forcer « nous sommes d’accord » lorsque l’issue est un report.

**Ponts à préparer :** question sur l’heure après une affirmation connue ; quotidien « voir quelqu’un » ; contraste entre horaire compris et horaire corrigé ; résumer un accord partiel ou une absence d’accord. Ce sont des besoins de séquençage à vérifier dans la réserve, pas une instruction d’ajouter immédiatement de nouvelles données.

**Essai de transfert :** la situation commence à une réception, se poursuit entre proches ou collègues, puis revient à un rendez-vous réel. Le registre est annoncé et ses formulations préparées ; ne pas changer simultanément le rôle, les mots, le temps et la politesse.

## Vérifier l’ensemble avec Claude

1. Pour chaque phrase principale, retrouver ce qui est déjà disponible dans la réserve et nommer les briques réellement préparées.
2. Relever la seule transformation visée ; isoler le lexique ou les formes qui ajouteraient une difficulté cachée.
3. Préparer aussi les questions et réponses reçues avant un rôle masqué ; le modèle produit ne suffit pas à enseigner l’oral de l’autre.
4. Contrôler les formulations propres à chaque langue et les aides phonétiques du lecteur. Les mêmes intentions n’imposent pas la même découpe grammaticale.
5. Faire essayer une substitution précoce, une transformation de passé, une négociation d’alternative et une tâche L10 ouverte sur les trois supports. Observer sens compris, phrase personnelle et adaptation à l’autre ; pas seulement la lecture ou le clic « Je connais ».
6. Présenter à Kartech les résultats et corrections proposées avant toute réalisation ou publication.

Le contenu actuel est conservé : les trois fils donnent un ordre d’acquisition et des occasions de réemploi. Ils ne prétendent pas couvrir tous les besoins ni garantir une maîtrise par leur seul achèvement.
