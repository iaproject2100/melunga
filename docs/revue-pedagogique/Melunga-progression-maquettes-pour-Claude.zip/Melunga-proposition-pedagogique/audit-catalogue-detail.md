# Audit du catalogue classique — progression et difficulté

Analyse locale au 20 octobre 2026, copie `49dca94` de `/workspace/melunga-preview`, pas une vérification de la version actuellement publiée. Aucun contenu modifié, aucune publication. Objectif : conserver la réserve, améliorer ses chemins d’apprentissage selon le principe d’assemblage de Kartech.

## Portée réelle

Contrôle automatique des 32 115 entrées de `DECKS` dans `melunga_deploy/app.html`, puis lecture raisonnée par langue et par niveau : premiers exemples, milieu, fin de liste, entrées les plus courtes/longues comme pistes de contrôle, formules de secours et transitions communes. La longueur n’est **pas** employée comme mesure de difficulté. Cette revue ne certifie ni chaque traduction ni l’oral natif des 32 115 entrées.

Les modes `L<n>` sélectionnent `lv === n && cat === 'core'` dans `setMode()`. Les cartes `bonus`, `vocab`, `template` et `basics` sont une réserve supplémentaire, pas nécessairement le parcours de niveau directement visible. Le parcours `path` possède un classement `pathLv` distinct : ne pas confondre les deux numérotations.

## Inventaire complet automatique

| Langue étudiée | Entrées toutes catégories | Entrées core | Core L1 | Occurrences supplémentaires d’un même texte | Textes identiques répartis sur plusieurs niveaux |
|---|---:|---:|---:|---:|---:|
| Français | 4 500 | 3 097 | 272 | 4 | 0 |
| Anglais | 4 502 | 3 230 | 308 | 4 | 1 |
| Espagnol | 4 672 | 3 621 | 224 | 0 | 0 |
| Chinois | 4 903 | 2 371 | 224 | 5 | 2 |
| Italien | 4 509 | 2 818 | 318 | 88 | 45 |
| Japonais | 4 509 | 3 173 | 262 | 205 | 92 |
| Coréen | 4 520 | 3 534 | 270 | 207 | 112 |

Aucun texte cible vide ni numéro de niveau hors 1–10 dans ce contrôle. Les doublons ne sont pas tous des erreurs : un même énoncé peut exprimer plusieurs sens selon la situation. Le contexte doit alors être rendu explicite, et les révisions ne doivent pas supposer que les deux emplois sont acquis ensemble.

## Constats prioritaires, avec exemples vérifiables

1. **Le L1 contient parfois une opération avancée au milieu de formules simples.** En anglais, `Since you're here, stay for dinner.` est `core`, L1. Elle combine cause et impératif, sans progression intermédiaire explicitée par sa présence dans la liste. La garder pour une séquence ultérieure ou comme bloc de compréhension contextualisé.
2. **Espagnol L1 : comparaison complexe.** `En realidad, es más fácil de lo que parece.` est `core`, L1 : connecteur, comparaison et proposition relative. La phrase est utile mais n’a pas la même charge qu’une première substitution après `Quiero`.
3. **Espagnol L1 : négation et impératif.** `Por último, no olvides cerrar la puerta.` est `core`, L1. La reclasser selon les structures déjà vues, plutôt que la mettre au même rang qu’un simple choix de boisson.
4. **Espagnol L1 : pronom attaché à un infinitif.** `En cualquier caso, ya es tarde para cambiarlo.` est `core`, L1. Peut servir d’enrichissement, après préparation des blocs, sans devenir un obstacle de débutant.
5. **Français L1 : ajout discursif.** `De plus, le petit-déjeuner est inclus.` est `core`, L1. Une formule hôtelière entendue peut être apprise en bloc, mais son connecteur n’est pas un premier exercice universel d’assemblage.
6. **Les formules de dépannage sont parfois tardives.** `Je ne comprends pas.` : français `core` L4 ; `No entiendo.` : espagnol `core` L1 ; `I don't understand.` : anglais `core` L3 ; `我不懂` : chinois `core` L2. La complexité linguistique diffère, mais un bloc de secours doit être accessible dès le départ dans chaque parcours.
7. **Ralentir l’interlocuteur arrive tard dans plusieurs catalogues.** `Más despacio, por favor.` : espagnol `core` L5 ; `Can you speak more slowly?` : anglais `core` L5 ; `请说慢一点。` : chinois `core` L4. Prévoir une voie courte dès L1, puis une version plus développée ultérieurement.
8. **Une même fonction quotidienne n’a pas de point d’entrée commun.** `Je voudrais un café.` est français `core` L3 ; `Vorrei un caffè.` italien `core` L2 ; `コーヒーをお願いします。` japonais `core` L5. Ne pas imposer la même grammaire aux langues, mais aligner la capacité pratique « demander une boisson » tôt, avec la formule adaptée.
9. **Chinois : des formes courtes exigent du contexte.** Les cartes L1 `只`, `就`, `又` ne constituent pas en elles-mêmes une structure productive comprise. Les garder reliées à une phrase et à un contraste de sens, sans demander leur maîtrise isolée.
10. **Chinois : un modèle de quotidien peut être plus avancé dans le catalogue qu’un groupe complexe introduit tôt ailleurs.** `再来一碗米饭。` est `core` L6. C’est une occasion de réemployer un compteur et une commande connus ; sa difficulté dépend de ces acquis. La conserver comme étape de réemploi, pas simplement comme « phrase de niveau six ».
11. **L’entrée classique coréenne contient aussi des fragments isolés à haut niveau.** `까지`, traduit « jusqu’à », est `core` L10. Le mot peut avoir des usages avancés, mais une carte isolée ne montre pas ce qui justifie L10 ni ce qu’il faut assembler. Prévoir une phrase simple puis des usages plus riches avec un contexte.
12. **Les niveaux supérieurs sont fortement spécialisés dans plusieurs langues.** En espagnol L9, 157 cartes core sur 186 portent un thème professionnel `biz` ou sectoriel ; français L9 : 86/132 ; anglais L9 : 88/132 ; italien L9 : 78/115 ; japonais L9 : 88/137. Ce décompte suit les tags du catalogue, pas une mesure linguistique. Garder ces contenus comme parcours professionnel ; une conversation quotidienne avancée doit avoir un chemin distinct.
13. **Exemple de spécialisation qui peut couper le fil conducteur.** Les premières cartes `core` L9 françaises incluent `Pouvez-vous m'envoyer des échantillons ?` et `Nous vous garantissons la qualité.` ; en espagnol `¿El producto tiene marca CE?` ; en japonais `この工場は量産しています。`. Elles sont pertinentes pour le commerce mais ne devraient pas devenir des prérequis à une conversation familiale, de voisinage ou de voyage.
14. **Même texte, apprentissages différents.** Japonais `寒いです。` existe en L1 « J’ai froid » et L2 « Il fait froid ». C’est une différence contextuelle légitime. Coréen `감사합니다.` existe en L1 « Merci » et L10 « Cordialement ». Ce dernier cas demande aussi une relecture de la traduction fonctionnelle ; le niveau ne doit pas masquer la différence d’usage.
15. **La clé des acquis est actuellement `lang + '|' + d.t`.** Les deux variantes contextuelles précédentes partagent donc la même clé de mémoire. Un clic « Je connais » peut supprimer les autres occurrences du parcours ordinaire sans que leur sens ou leur usage ait été essayé. Conserver les contenus, mais définir l’unité d’acquisition avant de déduire une maîtrise par niveau.

## Lecture globale des dix niveaux

| Niveau actuel | Diagnostic sur le catalogue | Amélioration proposée |
|---|---|---|
| L1 | Bon réservoir de salutations et besoins ; volume de 224–318 core, avec quelques constructions disproportionnées | Choisir un chemin débutant court ; une structure et des substitutions connues à la fois ; réserve accessible sans obligation de tout mémoriser |
| L2 | Beaucoup de réponses et actions utiles ; lexique et structure restent mélangés | Organiser par prolongement des structures L1 : quantité, complément, choix ; préparer les réponses reçues |
| L3 | Demandes courantes et déplacement ; aucune assurance que l’ordre de liste respecte les prérequis | Transformer les structures connues en questions/réponses, puis enrichir ; ne pas ajouter tous les nouveaux mots en même temps |
| L4 | Bonne matière pour le quotidien, mais des besoins élémentaires peuvent n’apparaître qu’ici | Déplacer les formules de secours en accès débutant ; garder ici les formulations plus développées et la recombinaison |
| L5 | Transition vers commerce et demandes spécifiques, en plus du quotidien | Maintenir un fil quotidien principal ; travailler temps ou politesse séparément du vocabulaire de métier |
| L6 | Commandes et fonctions simples côtoient un lexique spécialisé | Faire apparaître explicitement le réemploi de briques connues, puis la nouveauté ciblée ; séparer l’option professionnelle |
| L7 | Idiomes, passé, quotidien et négociation se mélangent | Créer des séquences homogènes : raconter, comparer ou expliquer, avec propositions déjà familières |
| L8 | Registre soutenu, répliques longues, spécialisés et mini-dialogues | Préparer chaque côté du dialogue ; évaluer le transfert, pas la mémorisation d’une réplique longue |
| L9 | Forte représentation professionnelle/formelle | Proposer deux applications des mêmes structures : quotidien et professionnel ; aucune obligation de maîtriser le jargon pour converser |
| L10 | Expressions de nuance intéressantes mais aussi petits fragments, mots et routines professionnelles | Organiser des situations ouvertes mêlant les acquis ; isoler enrichissement lexical et expertise de registre |

Ce tableau ne remplace pas une relecture de chaque carte. Il précise les changements de structure pédagogique à éprouver avant toute nouvelle affectation massive des niveaux.

## Recommandation de conservation

Garder le catalogue entier comme réserve éditoriale, avec ses formulations utiles et ses variantes. Constituer au-dessus une progression documentée : structure connue → substitution guidée → complément → transformation → échange → rappel ultérieur → nouvelle situation. Distinguer le cœur de conversation quotidienne, les variantes de registre et les parcours de métier. Une carte déplacée ou contextualisée n’est pas une carte perdue.

Pour les trois supports, les mêmes prérequis et objectifs doivent être suivis ; la taille d’écran ne doit changer ni l’ordre d’introduction ni la disponibilité de la phonétique et de l’audio. Les essais d’affichage et d’appareil restent à effectuer séparément.
