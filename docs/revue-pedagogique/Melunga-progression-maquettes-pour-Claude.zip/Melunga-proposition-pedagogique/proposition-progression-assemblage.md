# Melunga — progression par assemblage : proposition d’essai

Document local, non publié. Aucun changement des contenus, de l’application ou des branches distantes. À discuter avec Kartech et Claude avant réalisation.

## Principe fixé par Kartech

Dans toutes les langues, acquérir des mots et des blocs utiles en contexte, les réutiliser dans une structure, puis combiner et transformer les structures pour créer ses propres phrases. Les niveaux doivent montrer cette construction. L’inspiration du développement de l’enfant est un principe de conception ; elle ne prouve pas à elle seule l’efficacité du parcours pour un adulte.

## Ce que la revue montre

Lecture de la matrice et de la première variante de chaque modèle des dix niveaux des sept couples actuellement disponibles ; revue chinoise plus détaillée dans le dépôt. Ce contrôle porte sur la progression des modèles, pas sur une validation exhaustive de chaque variante, dialogue ou prononciation.

- L1 propose onze familles de phrases : identité, nom, envie, besoin, lieu, déplacement, sensation, goût, commande, prix et dépannage. C’est une réserve intéressante, mais trop de constructions pour une seule première séquence.
- Les salutations et réponses courantes ne sont pas organisées en socle explicite. « How are you? What's new? », « 元気ですか。 », « 잘 지내요? » figurent parmi les modèles L5 ; « Comment ça va ? » apparaît en L3 et « Ça va ? » en L5. Les rencontrer plus tôt comme blocs n’empêche pas de les enrichir ensuite.
- Certaines entrées font déjà un bon pont : « Vorrei un caffè » → « Vorrei due caffè » et « 커피 주세요 » → « 커피 두 잔 주세요 ». Il faut rendre ce lien visible et préparer séparément les compteurs.
- D’autres transitions ajoutent simultanément vocabulaire et construction : « I'm going to work » (L1) → « I'm going to visit my parents » (L6). Le premier déplacement peut préparer le second, mais lieu et action ne se substituent pas mécaniquement après le même fragment.
- « Me duele la cabeza », « 頭が痛いです », « 머리가 아파요 », « J’ai mal à la tête » sont en L9. Le bloc utile peut être rencontré bien plus tôt ; expliquer un incident ou un symptôme détaillé reste un objectif avancé.
- Les listes `reuses` des dialogues reposent sur des correspondances textuelles. Elles ne prouvent pas que les mots, les réponses reçues et les transformations ont été appris.

Le problème principal est l’absence d’un chemin explicite entre les briques, pas un manque de volume. Ne pas augmenter d’abord le nombre de phrases.

## Maquette d’une séquence

Exemple français illustratif, à adapter réellement à chaque langue :

1. **Découvrir** : audio + « Je veux de l’eau. » + sens. Réécoute et répétition possibles.
2. **Remplacer** : eau → thé. La phrase complète « Je veux du thé. » est présentée et prononcée ; le changement de déterminant est pris en charge.
3. **Comprendre l’autre** : découvrir « Tu veux quoi ? » et comprendre qu’on demande un choix de boisson. Dans une autre situation, employer un registre adapté.
4. **Répondre avec aide** : choisir eau ou thé puis écouter/dire sa phrase.
5. **Retrouver** : répondre à la question sans phrase étudiée visible, avec aide accessible.
6. **Transférer** : proposer une autre boisson déjà rencontrée, dans une autre scène. Une combinaison nouvelle et correcte constitue une meilleure indication de transfert que la seule répétition du modèle.
7. **Revoir plus tard** : retrouver la structure avant de l’enrichir.

Séquence suivante : « Je veux manger » puis « Je veux manger du riz ». Le passage d’un nom à un infinitif doit être enseigné ; il ne s’agit pas d’une case universelle acceptant tous les mots.

Ne pas imposer systématiquement ces sept écrans : c’est un scénario pédagogique, pas une maquette d’interface validée. Aucun changement du masquage actuel sans essai approuvé.

## Proposition de fil conducteur L1–L10

Les exemples illustrent la construction, pas un programme linguistique identique à traduire littéralement. Les formules de politesse et de secours restent accessibles dès le début.

| Niveau | Opération dominante | Exemple de réemploi | Ce qui doit être préparé |
|---|---|---|---|
| L1 | Comprendre et réutiliser quelques blocs ; remplacer un élément | Je veux de l’eau → Je veux du thé | Salutations, merci, besoin simple, question reçue ; premières mini-séquences distinctes |
| L2 | Compléter une structure connue | Je veux du thé → Je voudrais deux thés, s’il vous plaît | Quantité et forme polie travaillées séparément ; accords/compteurs adaptés |
| L3 | Transformer pour échanger | Je veux du thé → Tu veux du thé ? → Non, merci | Question, réponse positive/négative, relance ; une transformation à la fois |
| L4 | Combiner pour raconter le quotidien | Je mange à la maison → Le soir, je mange à la maison avec ma famille | Actions, lieu, moment et personnes déjà connus |
| L5 | Situer une action passée | Je mange à la maison → Hier, j’ai mangé à la maison | Verbe familier avant nouveaux verbes ; formes de passé/aspect propres à la langue |
| L6 | Réutiliser pour un projet et une invitation | Je vais au cinéma → Demain, je vais au cinéma. Tu viens ? | Distinguer déplacement, intention et futur ; comprendre acceptation/refus |
| L7 | Relier deux idées | Je reste à la maison parce que je suis fatigué | Chaque proposition déjà maîtrisée ; comparaison dans une séquence distincte |
| L8 | Adapter une demande et poser une condition | Je voudrais changer l’heure → Est-ce possible de venir demain ? | Demande simple connue, puis alternatives, puis condition ; pas tout simultanément |
| L9 | Réparer et résoudre | Je ne comprends pas → Vous voulez dire que je dois revenir demain ? | Clarification simple connue ; problème développé à partir de situations familières |
| L10 | Choisir et combiner librement | Raconter, expliquer son choix, répondre à une objection et proposer une solution | Situations nouvelles avec briques connues ; plusieurs réponses acceptables |

Un niveau contient plusieurs petites séquences. Il ne correspond ni à une seule séance ni à une équivalence CECRL certifiée. Des structures simples reviennent à tous les niveaux avec un contexte plus riche.

## Travail proposé avec Claude

Commencer par une seule chaîne L1 → L2 → L3, sur le thème boire/manger, en français → chinois et français → espagnol. Le chinois répond au retour débutant ; l’espagnol permet de vérifier que le principe ne dépend pas d’une langue unique.

Pour chaque mini-séquence, préparer dans un document d’essai :

- la capacité visée et un exemple de réponse autonome ;
- les mots/blocs déjà rencontrés, avec référence à leur séquence ;
- les nouveautés et la transformation exercée ;
- les phrases complètes validées, leurs lectures et leur audio prévu ;
- les questions/réponses de l’interlocuteur à préparer ;
- une combinaison nouvelle mais correcte et un exemple de combinaison impossible ;
- le rappel dans une séance suivante, puis dans un autre contexte.

Ne pas modifier les JSON ni ajouter des champs au chargeur à ce stade. Les documents d’essai permettent de valider le contrat pédagogique avant de décider de son éventuelle représentation technique.

## Critères d’essai

Observer si l’apprenant comprend la question, sait choisir un morceau, produit une variante non simplement recopiée, retrouve la structure après une interruption et la réutilise dans une autre scène. Noter les aides utilisées et les blocages. Un appui sur « Je connais » ne prouve ni la compréhension ni le transfert ; la reconnaissance vocale seule ne certifie pas la correction.

Ne pas fixer un taux de réussite ou un nombre de répétitions comme vérité scientifique sans données d’essai. Prévoir des reprises selon les difficultés observées, sans obliger l’apprenant à mémoriser tout le catalogue pour avancer.

## Message à transmettre à Claude

« Kartech précise le principe central : la progression doit venir de l’assemblage et du réemploi des mots et structures, pour créer ses propres phrases. La matrice actuelle fournit une réserve utile, mais les liens de prérequis et les étapes intermédiaires restent à expliciter. Avant tout enrichissement massif, préparons une maquette documentaire L1–L3 boire/manger pour fr→zh et fr→es : briques connues, une transformation principale par séquence, compréhension de l’interlocuteur, phrase complète correcte, réemploi inédit et rappel ultérieur. Ne change pas encore les données ou l’interface pour cette proposition ; Kartech valide l’essai avant réalisation, et aucune publication/fusion n’est autorisée sans sa validation. Codex poursuit la revue pédagogique des autres niveaux. »
