# Revue locale — le parcours soutient-il l’assemblage progressif ?

20 octobre 2026. Copie de travail à `49dca94`. Lecture des mécanismes et de la configuration, plus reproduction isolée des fonctions de comparaison. Aucun changement de contenu, d’interface, de dépôt distant ou de production. Aucun essai sur appareil dans cette revue.

## À conserver

Le parcours par familles (`PEDAGOGY_FAMILIES`, `app.html:2933`) est une base déjà présente : 26 familles par langue configurée, 151 occurrences de cartes, classées par niveau de parcours et par étape. Les phrases entières restent la référence ; il est possible de conserver la réserve tout en corrigeant son classement et sa séquence.

« Mes phrases » sépare découverte, variation, rappel puis dialogue (`construire.js:300`). La phrase complète sert à l’affichage et à l’audio. Les aides et la révélation sont accessibles. Ce cadre convient au principe de Kartech, sous réserve de préparer les nouveautés.

## Points directement liés à la progression

### 1. Les familles ne garantissent pas une seule structure — priorité forte

La configuration mêle parfois constructions productives et ressemblances de surface :

- Français L2 `Je vais + action` inclut « Je vais mieux. » : même début, sens et construction différents.
- Anglais L2 `I’m going to + action` commence par « I’m going to bed. » : `bed` est un lieu, pas une action à l’infinitif.
- Espagnol L2 `Voy a + acción` commence par « Voy a casa. » ; le lieu n’est pas une action.
- Chinois L2 `我要 + 动作` inclut « 我要两个 » : quantité elliptique, pas action.
- Italien L4 `Se + condizione` contient « Secondo me, è un errore. » : opinion sans condition.
- Japonais L7 famille discours rapporté contient « それで、はいと言いました。 » : l’action de dire oui n’enseigne pas directement le même mécanisme qu’un contenu rapporté « il a dit qu’il… ».

Proposition : conserver ces phrases ; distinguer les sens et gabarits, puis placer les exceptions dans une séquence ultérieure. Le critère de regroupement est l’opération réutilisable, pas la présence d’un fragment commun.

### 2. Les difficultés de langue sont parfois entremêlées dès le même niveau

Exemple français L3 cause : « Je mange parce que j’ai faim » puis « Je suis resté parce que j’avais promis » et « J’ai pris un parapluie parce qu’il allait pleuvoir ». Le lien causal est utile, mais les temps ajoutent d’autres difficultés.

Espagnol L4 condition : « Si tuviera tiempo, viajaría más » et « Si fuera tú, lo haría » ajoutent imparfait du subjonctif et conditionnel. On peut les conserver comme enrichissement après des conditions concrètes bâties sur des propositions connues.

Proposition : ne pas supprimer les tournures riches ; trier chaque famille en première découverte, variation proche, réemploi et enrichissement.

### 3. Le parcours coréen par familles n’est pas configuré

`PEDAGOGY_FAMILIES.languages` contient fr/en/es/zh/it/ja, mais pas ko. `guidedPool` renvoie `[]` si la langue n’a pas de configuration (`app.html:2941–2942`). Les cartes coréennes et les JSON conversation existent, mais ce parcours classique spécifique n’est donc pas équivalent pour cette langue.

### 4. Les cartes « connues » peuvent retirer les appuis et les réemplois prévus

`rateCard(true)` archive par clé `lang|texte`, puis `setMode` exclut ces cartes des modes ordinaires, y compris du parcours (`app.html:3470`, `3980–4009`, `4088`). La même phrase reprise dans une famille ultérieure disparaît donc si elle a été rangée plus tôt.

Exemples de reprises dans la configuration : « C’est où ? » figure dans deux familles L1 ; « 我需要一把伞。 » réapparaît L1/L5 ; plusieurs concessions réapparaissent L8/L10.

Une archive n’est pas une preuve d’aptitude à réutiliser une structure. Proposition à essayer : permettre une reprise guidée de la phrase en nouveau contexte même si elle est déjà connue, sans effacer l’archive. Distinguer état de carte et objectif de structure.

### 5. Le parcours est un ordre de cartes, sans prérequis explicites

`guidedPool` trie les familles et concatène leurs cartes (`app.html:2940–2957`). Il ne vérifie pas les mots déjà découverts, ni la compréhension de la réponse de l’interlocuteur. Il ne construit pas une nouvelle combinaison : la variation reste une phrase livrée dans les données.

Dans « Mes phrases », le sélecteur donne toutes les unités et les dialogues du niveau ; aucun apprentissage préalable n’est requis avant le dialogue (`construire.js:318–323`). L’apprenant y a son rôle caché dès l’entrée (`353–355`). Cela convient au rappel, mais ne garantit pas une première exposition.

Proposition : préparer une séquence documentaire courte « entendu → compris → remplacé → combiné → réemployé » avant toute modification d’interface. Une porte d’accès libre peut rester, sans appeler ce choix une progression maîtrisée.

### 6. Les calendriers de révision sont distincts de l’archive et de l’assemblage

L’archive « Je connais » et la liste « À revoir » n’écrivent pas dans le calendrier `SRS`. Celui-ci est alimenté par `rate(grade)` dans les modes review/recall (`app.html:3980`, `4094–4104`). Une erreur en SRS fixe la prochaine échéance à un jour et retire la carte de la séance ; une carte difficile en mode ordinaire est réinsérée 12–16, puis 22–26, puis 36–40 positions plus loin.

Il existe donc une révision, mais on ne peut pas conclure que toutes les phrases vues entrent automatiquement dans un parcours de consolidation. La reprise de « Mes phrases » ne stocke que niveau et unité (`construire.js:278–298`), pas les mots, structures ou erreurs.

Proposition : établir d’abord les rappels pédagogiques souhaités et les capacités suivies ; adapter ensuite les états techniques. Ne pas assimiler dernier contenu ouvert et compétence acquise.

## Correction nécessaire avant d’utiliser le rappel comme indication de progrès

`app.html:4131–4158` normalise les réponses avec un filtre qui conserve lettres latines, chiffres et idéogrammes CJK, mais supprime hangul et kana. Reproduction locale des fonctions exactes :

| Saisie | Référence | Résultat actuel |
|---|---|---|
| 커피 주세요. | 커피 주세요. | refusée, comparaison vide |
| ありがとう。 | ありがとう。 | refusée, comparaison vide |
| 水を飲みます。 | 水を飲みません。 | acceptée, kana et négation supprimés, restent 水飲 des deux côtés |

Le rappel écrit et la comparaison des transcriptions micro partagent ce mécanisme. Il ne faut donc pas interpréter ces résultats comme une maîtrise du coréen/japonais.

Même en alphabet latin, `_recallDiff` compare un ensemble de mots sans tenir compte de l’ordre : « I do not want tea » face à « I want tea » affiche 100 % de mots retrouvés, alors que `matchPhrase` refuse cet exemple. Le pourcentage peut contredire la réussite pédagogique. Ce n’est pas une mesure de prononciation.

Proposition : traiter les écritures Unicode de la langue et le sens des négations ; nommer précisément le retour « correspondance de transcription » si une mesure textuelle est conservée. Accepter progressivement des réponses alternatives validées quand l’objectif est de communiquer, plutôt que réciter une unique chaîne.

## Application aux trois supports

Les mécanismes décrits sont dans les fichiers partagés. Le rendu ordinateur les adapte et s’arrête en contexte natif (`desktop-lessons.js:3`). Le runtime APK d’essai modifie surtout présentation, origines et ouverture des niveaux (`tools/apk-test/mobile-runtime.js:5–6`). Il ne corrige pas ces liens pédagogiques à lui seul.

La reprise et la révision observées ici sont locales au navigateur/application. Ne pas les confondre avec un transfert de progression entre appareils. Vérifier les trois supports sur le même petit scénario, sans prétendre qu’une lecture de code remplace l’essai APK.

## Décision proposée

Conserver le contenu. Prioriser : (1) correction des retours faux du rappel ; (2) nettoyage pédagogique des familles ; (3) premiers parcours courts et prérequis explicites ; (4) réemploi des acquis sans disparition par archive ; (5) essai chinois/espagnol L1–L3 sur les trois supports. Aucun de ces changements n’est exécuté dans ce document.
