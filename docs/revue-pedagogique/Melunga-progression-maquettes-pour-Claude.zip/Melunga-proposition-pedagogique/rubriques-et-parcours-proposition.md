# Rubriques et parcours — proposition cohérente pour Melunga

Document de travail local pour Kartech et Claude, 20 octobre 2026. Source examinée : copie `49dca94` de `melunga_deploy`. Aucun changement de site, d’application, de données ou de droits. Cette proposition doit être relue avec Claude et validée par Kartech avant réalisation ou publication.

## Un même principe sur les trois supports

Le contenu est conservé comme réserve. Le chemin d’apprentissage doit relier ses éléments : entendre/comprendre → imiter → remplacer un morceau → compléter → transformer → combiner → répondre → réemployer dans une nouvelle situation.

Sur ordinateur, site mobile et application, une même séquence doit présenter les mêmes acquis, nouveautés et phrases complètes. Les gestes et la disposition peuvent varier. Une lecture des fichiers ne confirme ni le rendu réel de tous les appareils, ni les contenus actuellement publiés : la présente revue concerne la copie locale, dont les nouveautés conversation restent sur la branche d’essai.

## Inventaire réel et rôle proposé

| Rubrique actuelle / source | Fonction actuelle | Place proposée dans la méthode |
|---|---|---|
| Accueil du site — `index.html`, `desktop-home.js` | Présentation, exemples, accès gratuit/Premium et connexion ; présentation différente selon écran | Montrer une seule petite chaîne concrète de construction, puis ouvrir un parcours adapté au débutant. Conserver les exemples comme démonstrations identifiées, pas comme preuve de compétence déjà acquise |
| Présentation de la méthode — `index.html:251–275`, panneau Comment ça marche dans `app.html:4431` | Écouter, mémoriser, recombiner ; phonétique adaptée ; progression L1–L10 | Ajouter explicitement comprendre l’interlocuteur et transformer une structure. Les promesses doivent correspondre à ce que la séquence permet de faire ; pas de garantie chiffrée sans mesure |
| Leçons / cartes classiques — `DECKS`, `app.html:2931` | Phrase étudiée, phonétique, sens, audio ; navigation et classement À revoir/Je connais | Réserve de découverte et d’entraînement. Chaque carte employée dans un parcours doit avoir un rôle : première rencontre, variante proche, réemploi ou enrichissement |
| Tout — `app.html:3295`, `3442` | Parcourir le catalogue accessible, avec filtre des cartes archivées | Bibliothèque libre. Ne pas demander au débutant de tout parcourir avant d’apprendre à converser |
| Parcours guidé — `PEDAGOGY_FAMILIES`, `guidedPool`, `app.html:2932–2957` | Familles classées L1–L10 et suite ordonnée de cartes | Entrée principale pour apprendre progressivement. Corriger les familles qui confondent constructions/sens et expliciter les étapes d’assemblage. Le coréen manque actuellement dans cette configuration |
| Niveaux L1–L10 — `app.html:3320`, `3440–3470` | Filtrer les cartes `core` selon leur niveau de catalogue ; autre niveau de parcours dans `_path.pathLv` | Repères de capacités, pas uniquement de longueur/volume. Définir la correspondance entre niveau de carte, niveau guidé et niveau conversation avant de prétendre à une progression commune |
| Mes phrases — pastille et panneau `construire.js:300–336`, `448–460` | Choisir un niveau puis une situation, découvrir les variantes, rappeler une phrase et converser | Atelier d’utilisation des structures déjà découvertes. Au début, choix simple et guidé ; plus tard, combinaisons et choix de réponse plus libres. Conserver la phrase complète comme référence pour accords/particules |
| Dialogues — `construire.js:353–387` | Un tour à la fois, rôles nommés, rôle apprenant masqué par défaut, révélation et audio | Aboutissement d’une séquence préparée. D’abord comprendre un échange complet, puis répondre avec aide, enfin sans modèle. Les réponses de l’interlocuteur font partie de ce qu’il faut apprendre |
| Bases — `app.html:3300`, `3449` | Cartes `cat=basics`, notamment nombres/couleurs | Ressource introduite au moment utile : un/deux pour commander, couleur pour choisir. Éviter un détour imposé par une longue liste sans usage |
| Mots — `app.html:3301`, `3450` | Vocabulaire isolé `cat=vocab` | Réserve de morceaux à réutiliser immédiatement dans une structure connue. Ne pas présenter le seul nombre de mots vus comme compétence de conversation |
| Quotidien — `app.html:3302` | Packs quotidien, questions, émotions, connecteurs, idiomes | Situations de transfert. Questions et émotions simples tôt ; connecteurs selon les structures déjà connues ; idiomes en enrichissement contextualisé |
| Voyage — `app.html:3304–3306` | Touriste, restaurant, culture | Parcours contextualisé : demander, comprendre une réponse, préciser, puis résoudre un problème. Découvrir l’expression simple avant une scène complète gare/hôtel |
| Business / Sourcing — `app.html:3308–3316` | Affaires, formel, textile, électronique, meubles, éclairage, jouets, chaussures, sacs, machines ; affichage dépendant du couple/langue | Parcours spécialisé facultatif pour un besoin professionnel. Conserver ces contenus ; éviter de les faire passer comme passage obligé de la conversation quotidienne |
| Révision — `app.html:3452–3457`, `4094–4105` | Cartes dues et nouvelles cartes, rappel puis auto-évaluation qui alimente un calendrier local | Consolider des acquis réellement rencontrés ; permettre la réactivation d’une structure dans un autre contexte. Distinguer reconnaissance, rappel et usage |
| Rappel — `app.html:3458–3463`, `3878–3924`, `4143–4158` | Traduction comme indice, saisie ou transcription micro, comparaison à une référence | Entraînement après découverte, adapté aux écritures ; ne pas exiger l’écriture pour prouver une capacité orale. Corriger le filtrage Unicode avant de s’appuyer sur ses résultats en japonais/coréen |
| À revoir — `app.html:3465`, `3980–4007` | Marquage local et réinsertion des cartes dans une séance ordinaire | Liste d’appuis à reprendre en petites quantités ; identifier si le blocage porte sur sens, son ou structure plutôt que multiplier mécaniquement les mêmes cartes |
| Je connais / Rangées — `app.html:3466`, `3470`, `3988–3993` | Archive locale, exclusion de plusieurs parcours | Conserver l’archive, tout en permettant le réemploi prévu d’une phrase connue. Connaître une carte ne prouve pas qu’on sait poser une question ou combiner la structure |
| Phonétique / lecture / pinyin — `phonOf`, `app.html:3184–3201`; `phonBox`, `construire.js:391–406` | Aide adaptée au lecteur, lecture supplémentaire pour zh/ja/ko dans les conversations, accès à l’audio | Appui disponible dans toutes les phases où l’apprenant en a besoin. La phonétique fait partie de la méthode ; ne pas la retirer arbitrairement pour fabriquer une difficulté. Distinguer la prononciation adaptée à la langue maternelle de la romanisation de la langue étudiée |
| Micro et auto-test — `app.html:4091`, `4120–4236` | Masquage, reconnaissance vocale et similarité textuelle | Occasion de produire et de s’écouter ; pas examen fiable de prononciation ou de sens. Prévoir réécoute/révélation sans micro compatible, et des alternatives de réponse lorsque l’objectif le permet |

## Cohérence des dix niveaux proposée

Les niveaux suivants décrivent des capacités ; les mêmes situations et mots reviennent avec davantage d’autonomie. Les détails de syntaxe et l’ordre exact sont adaptés à chaque langue.

| Niveau | Place dans l’assemblage | Rubriques mobilisées |
|---|---|---|
| L1 | Comprendre quelques blocs, demander simplement, remplacer un élément connu | Parcours guidé très court, cartes utiles, phonétique/audio, premier échange préparé |
| L2 | Compléter : quantité, action, lieu ou moment ; une nouveauté à la fois | Bases ciblées, atelier Mes phrases, mini-dialogues |
| L3 | Transformer en question, négation et réponse ; relancer | Questions/quotidien, atelier, dialogues de choix |
| L4 | Combiner pour parler de sa journée et de ses proches | Quotidien, mots réutilisés en contexte, récit présent simple |
| L5 | Réutiliser des actions connues dans le passé | Leçons ciblées et dialogues de récit ; revoir les verbes connus |
| L6 | Parler d’un projet, inviter, accepter/refuser et proposer une alternative | Loisirs, voyage, conversations préparées |
| L7 | Relier raisons, avis et comparaisons | Connecteurs, situations quotidiennes, atelier de combinaison |
| L8 | Adapter une demande et négocier une solution | Demandes, services, puis parcours professionnel selon besoin |
| L9 | Clarifier, reformuler, résoudre un imprévu en plusieurs étapes | Dialogues avec variations et clarification, rappel des formules de secours déjà rencontrées tôt |
| L10 | Choisir et combiner librement des ressources connues | Conversations ouvertes, situations nouvelles, retours ciblés et enrichissement de registre |

La politesse, les salutations et les formules « je ne comprends pas / répétez » ne sont pas réservées à un niveau avancé. Les registres spécialisés ou expressions idiomatiques sont des approfondissements, pas la définition unique de L10.

## Cohérence des sept langues et limites actuelles

Les cartes classiques contiennent sept langues étudiées : français, anglais, espagnol, chinois, italien, japonais, coréen, avec plusieurs champs de traduction et de prononciation selon le lecteur.

Le nouveau parcours conversation n’offre actuellement que **sept couples**, d’après `conversation-loader.js:29` : français → espagnol, anglais, chinois, italien, japonais, coréen ; chinois → français. Il ne s’agit pas de quarante-deux parcours conversation finalisés. Les fichiers de travail pour d’autres publics ne suffisent pas à les annoncer comme disponibles.

La même intention communicative ne donne pas une traduction mot à mot de la structure française. Les particules et terminaisons japonaises/coréennes, les compteurs et réponses chinoises, les accords et registres doivent être portés par les phrases complètes et les séquences propres à chaque langue. La phonétique doit aussi être rédigée pour le public réel du couple.

## Local, distant et application

- Les cartes `DECKS` et la configuration guidée sont embarquées dans `app.html` de la copie utilisée. Une application contenant une ancienne copie ne bénéficie pas automatiquement de tous les changements du site.
- Les conversations sont des JSON chargés par `conversation-loader.js`. En HTTPS web, ils suivent normalement l’origine du site ; dans l’application locale, ils utilisent `melunga.com` sauf origine d’essai définie explicitement.
- Le runtime APK d’essai versionné définit l’aperçu Netlify #8 comme origine de contenu et ouvre les niveaux pour l’essai (`tools/apk-test/mobile-runtime.js:5–6`). Cela ne prouve pas que l’application publiée partage déjà exactement la même version.
- Ordinateur : `desktop-lessons.js` adapte le rendu des leçons et sort explicitement en environnement natif. Mobile web et APK ont des styles différents. Un test de la même séquence doit vérifier phrase, phonétique, traduction, audio, accès aux aides et navigation sur les trois.
- La reprise et les archives examinées sont dans le stockage local. Ne pas promettre une synchronisation entre ordinateur et téléphone uniquement parce qu’un compte existe.

## Rubriques utilitaires : garder leur rôle distinct

Compte/connexion servent l’accès et l’identification ; Premium et boutique gèrent des droits ; voix/vitesse soutiennent l’écoute ; palette règle le confort visuel. Aucune modification de ces règles n’est proposée ici. Un changement pédagogique ne doit ni débloquer de droits ni changer les tarifs. Les fonctions d’essai doivent rester explicitement séparées de la publication.

## Proposition à relire avec Claude avant réalisation

1. Conserver le catalogue et établir pour chaque phrase employée : découverte, variante, réemploi ou enrichissement.
2. Définir un chemin court de référence à travers les rubriques, en prenant le prototype multilingue de Kartech comme support de discussion.
3. Aligner les trois sens actuels du mot niveau : catalogue, familles guidées, conversation.
4. Corriger les retours de rappel faux et les familles mal regroupées avant d’interpréter les résultats des essais.
5. Faire essayer la même séquence sur ordinateur, mobile web et APK, puis obtenir la validation de Kartech avant toute mise en ligne.

L’objectif n’est pas d’ajouter de nouvelles rubriques : chaque rubrique existante doit contribuer clairement à la création progressive de phrases et à la conversation.

## Règle précisée par Kartech : les leçons sont faites de phrases

La phrase utile en contexte est l’unité principale de chaque leçon, dès L1. Elle est affichée, traduite, accompagnée de la phonétique adaptée au lecteur et prononçable en entier. Les mots et morceaux remplaçables sont découverts dans une phrase ; une liste de mots ou de règles ne remplace pas la leçon. Les rubriques de vocabulaire servent à retrouver des briques avec leurs phrases d’emploi.

Exemple de chaîne illustrative : « Je veux de l’eau. » → « Je veux du thé. » → « Je veux boire. » → « Je veux boire du thé. » → « Tu veux boire du thé ? ». Chaque changement de construction est préparé dans une séquence distincte. La phrase complète correcte fait autorité, avec les adaptations propres à chaque langue.

Cette règle concerne les leçons classiques autant que Mes phrases, les révisions, les thèmes et les dialogues, sur les trois supports. Les expressions courtes naturelles (« Bonjour », « Merci ») restent possibles comme répliques en situation, sans imposer artificiellement un sujet et un verbe à chaque échange.
